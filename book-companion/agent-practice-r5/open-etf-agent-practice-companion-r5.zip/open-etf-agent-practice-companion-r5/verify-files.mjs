import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
function stop(code) { const error = new Error(code); error.code = code; throw error; }
function safePath(name) {
  if (typeof name !== 'string' || !name || name.includes('\\') || name.includes('\0') || path.posix.isAbsolute(name)) stop('UNSAFE_PATH');
  const pieces = name.split('/');
  if (pieces.some(piece => !piece || piece === '.' || piece === '..' || piece.includes(':'))) stop('UNSAFE_PATH');
  let current = root;
  for (const piece of pieces) {
    current = path.join(current, piece);
    if (!fs.existsSync(current)) stop('FILE_MISSING');
    if (fs.lstatSync(current).isSymbolicLink()) stop('SYMLINK_REFUSED');
  }
  return current;
}
try {
  const manifestPath = safePath('file-manifest.json');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (manifest.schema !== 'agent-practice-companion@1' || !Array.isArray(manifest.files) || manifest.files.length === 0) stop('INVALID_MANIFEST');
  const seen = new Set();
  for (const entry of manifest.files) {
    if (!entry || seen.has(entry.path) || !Number.isSafeInteger(entry.bytes) || entry.bytes < 0 || !/^[0-9a-f]{64}$/.test(entry.sha256)) stop('INVALID_MANIFEST');
    seen.add(entry.path);
    const name = safePath(entry.path);
    if (!fs.lstatSync(name).isFile()) stop('NOT_A_FILE');
    const bytes = fs.readFileSync(name);
    if (bytes.length !== entry.bytes) stop('SIZE_MISMATCH');
    if (createHash('sha256').update(bytes).digest('hex') !== entry.sha256) stop('SHA256_MISMATCH');
  }
  console.log(JSON.stringify({ status: 'matched', files: manifest.files.length, release: manifest.release, scope: 'listed payload bytes only; not execution, authenticity or unlisted-file review' }));
} catch (error) {
  console.error(JSON.stringify({ status: 'rejected', code: error.code || 'INVALID_MANIFEST' }));
  process.exitCode = 1;
}
