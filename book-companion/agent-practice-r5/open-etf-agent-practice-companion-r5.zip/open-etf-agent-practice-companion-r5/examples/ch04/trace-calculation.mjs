import { assertFixedRepository } from '../check-base.mjs';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';

const args = process.argv.slice(2);
if (args.length !== 4 || args[0] !== '--repo' || args[2] !== '--result') {
  throw new Error('Usage: node trace-calculation.mjs --repo REPO --result RESULT_JSON');
}
const repository = assertFixedRepository(resolve(args[1]));
const { createResultStore } = await import(pathToFileURL(join(repository, 'src/results.mjs')));
const result = JSON.parse(await readFile(args[3], 'utf8'));
assert.equal(result.caseId, 'portfolio-rebalance');
assert.equal(result.mode, 'fixture');
assert.equal(result.status, 'completed');
const manifest = JSON.parse(await readFile(join(result.directory, 'manifest.json'), 'utf8'));
const store = await createResultStore({ directory: result.directory, readOnly: true });
const calculation = await store.readCalculation(manifest.calculations[0].ref.resultRef);
const source = await store.read(calculation.binding.sourceRef);
const rows = JSON.parse(source.text).rows;
const binding = calculation.binding;
assert.equal(rows[binding.baseline.rowIndex].id, 'dividend-current');
assert.equal(rows[binding.current.rowIndex].id, 'dividend-target');
assert.equal(rows[binding.baseline.rowIndex].value, calculation.inputs.baseline);
assert.equal(rows[binding.current.rowIndex].value, calculation.inputs.current);
assert.equal(calculation.difference, -10000);
const request = {
  resultRef: binding.sourceRef,
  selection: { offset: 0, limit: 12 },
  baselineRow: 0,
  currentRow: 1
};
const complete = await store.resolveComparison(request);
assert.equal(complete.available, true);
const incomplete = await store.resolveComparison({ ...request, selection: { offset: 0, limit: 1 } });
assert.equal(incomplete.available, false);
assert.equal(incomplete.code, 'OPERAND_NOT_SELECTED');
const wrongCategory = await store.resolveComparison({ ...request, currentRow: 3 });
assert.equal(wrongCategory.available, true);
assert.equal(wrongCategory.binding.current.rowId, 'overseas-target');
console.log(JSON.stringify({
  check: 'original-calculation-binding',
  status: 'passed',
  originalPair: {
    baseline: binding.baseline.rowId,
    current: binding.current.rowId,
    difference: calculation.difference,
    currency: binding.currency,
    dataAsOf: binding.dataAsOf
  },
  narrowWindow: { available: incomplete.available, code: incomplete.code },
  semanticCounterexample: {
    available: wrongCategory.available,
    baseline: wrongCategory.binding.baseline.rowId,
    current: wrongCategory.binding.current.rowId,
    explanation: 'Valid source binding and matching metadata do not prove the selected asset categories answer the task.'
  },
  providerCalls: 0,
  writesToOriginalRun: false
}, null, 2));
