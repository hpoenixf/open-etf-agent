import { assertFixedRepository } from '../check-base.mjs';
import assert from 'node:assert/strict';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';

const args = process.argv.slice(2);
if (args.length !== 4 || args[0] !== '--repo' || args[2] !== '--output') {
  throw new Error('Usage: node observe-the-loop.mjs --repo REPO --output OUTPUT_ROOT');
}
const repo = assertFixedRepository(resolve(args[1]));
const outputRoot = resolve(args[3]);
const { run } = await import(pathToFileURL(join(repo, 'src/runtime.mjs')));
const { preparePortfolioRebalance } = await import(pathToFileURL(join(repo, 'src/portfolio-rebalance-demo.mjs')));
const prepared = preparePortfolioRebalance();
const original = prepared.gateway;
const observations = [];
const gateway = {
  mode: 'fixture',
  async next(input) {
    const prior = input.messages.filter(message => message.role === 'tool');
    const proposal = await original.next(input);
    observations.push({
      round: observations.length + 1,
      receivedToolResults: prior.length,
      receivedStatuses: prior.map(message => message.result.status),
      proposal: proposal.kind,
      tools: proposal.kind === 'calls' ? proposal.calls.map(call => call.name) : []
    });
    return proposal;
  }
};
const completed = await run({
  question: 'Compare the fixed synthetic portfolio and targets, preserve original calculations, and save a report with CSV evidence.',
  ...prepared,
  gateway,
  outputRoot: join(outputRoot, 'observed'),
  requireReport: true
});
assert.equal(completed.status, 'completed');
assert.deepEqual(observations.map(row => row.receivedToolResults), [0, 1, 7, 14, 15]);
const missingReport = await run({
  question: 'Save the required synthetic report.',
  gateway: { mode: 'fixture', async next() { return { kind: 'final', text: 'The report is saved.' }; } },
  outputRoot: join(outputRoot, 'missing-report'),
  requireReport: true
});
assert.equal(missingReport.status, 'failed');
assert.equal(missingReport.code, 'REPORT_REQUIRED');
console.log(JSON.stringify({
  check: 'observe-public-runtime-loop',
  mode: 'fixture',
  providerCalls: 0,
  observations,
  completed: { status: completed.status, directory: completed.directory, rounds: completed.rounds, toolsDispatched: completed.toolsDispatched },
  earlyFinal: { status: missingReport.status, code: missingReport.code, receipt: missingReport.receipt ?? null },
  semanticStatus: 'unreviewed'
}, null, 2));
