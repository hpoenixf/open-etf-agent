import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { assertFixedRepository } from '../check-base.mjs';
const args = process.argv.slice(2);
if (args.length !== 6 || args[0] !== '--repo' || args[2] !== '--result' || args[4] !== '--output') {
  throw new Error('Usage: node stop-at-the-limit.mjs --repo REPO --result CH03_RESULT_JSON --output OUTPUT_ROOT');
}
const repo = assertFixedRepository(resolve(args[1]));
const { preparePortfolioRebalance } = await import(pathToFileURL(join(repo, 'src/portfolio-rebalance-demo.mjs')));
const { run } = await import(pathToFileURL(join(repo, 'src/runtime.mjs')));
const { createRootBudget } = await import(pathToFileURL(join(repo, 'src/cooperation.mjs')));
const { createResultStore } = await import(pathToFileURL(join(repo, 'src/results.mjs')));
const { projectContext } = await import(pathToFileURL(join(repo, 'src/context.mjs')));
const output = resolve(args[5]);
const cases = [];
for (const scenario of [
  { name: 'two-rounds', limits: { maxRounds: 2, maxTools: 16 }, expected: 'ROUND_LIMIT', tools: 7 },
  { name: 'six-tools', limits: { maxRounds: 5, maxTools: 6 }, expected: 'TOOL_LIMIT', tools: 1 },
  { name: 'shared-two-model', limits: { maxRounds: 5, maxTools: 16 }, rootBudget: createRootBudget({ model: 2, tool: 16 }), expected: 'ROOT_BUDGET_EXHAUSTED', tools: 7 }
]) {
  const prepared = preparePortfolioRebalance();
  const result = await run({
    ...prepared, question: 'Compare the same synthetic portfolio with its fixed illustrative targets. Save a report only if the work completes.',
    requireReport: true, limits: scenario.limits, ...(scenario.rootBudget ? { rootBudget: scenario.rootBudget } : {}),
    outputRoot: join(output, scenario.name)
  });
  assert.equal(result.status, 'failed');
  assert.equal(result.code, scenario.expected);
  assert.equal(result.toolsDispatched, scenario.tools);
  assert.equal(result.receipt, null);
  cases.push({ name: scenario.name, status: result.status, code: result.code, rounds: result.rounds, toolsDispatched: result.toolsDispatched, rootUsage: result.rootUsage, reportSaved: false, directory: result.directory });
}

// This is a constructed input to the pure projector, not a fabricated Runtime trace.
// Its source and calculation payloads are read from the real, earlier Chapter 3 Run.
const prior = JSON.parse(await readFile(resolve(args[3]), 'utf8'));
assert.equal(prior.caseId, 'portfolio-rebalance');
const store = await createResultStore({ directory: prior.directory, readOnly: true });
const descriptor = (await store.list())[0];
const source = await store.read(descriptor.resultRef);
const calculationDescriptor = (await store.listCalculations())[0];
const calculation = await store.readCalculation(calculationDescriptor.resultRef);
const pair = (id, name, arguments_, value) => [
  { role: 'assistant', calls: [{ id, name, arguments: arguments_ }] },
  { role: 'tool', callId: id, result: { callId: id, status: 'succeeded', value } }
];
const messages = [
  { role: 'user', content: 'Synthetic projector exercise: retain the original portfolio question and latest complete calculation group.' },
  ...pair('projection-source', 'read_portfolio_fixture', {}, { ...source, resultRef: descriptor.resultRef }),
  ...pair('projection-calc', 'calculate_change', { resultRef: descriptor.resultRef, selection: { offset: 0, limit: 12 }, baselineRow: 0, currentRow: 1 }, { ...calculation, resultRef: calculationDescriptor.resultRef })
];
const original = structuredClone(messages);
const bytes = value => Buffer.byteLength(JSON.stringify(value));
const beforeBytes = bytes(messages);
const maxBytes = beforeBytes - 500;
const projected = await projectContext({ messages, maxBytes, lookupSource: id => store.resolve(id) });
assert.deepEqual(messages, original);
assert.deepEqual(projected[0], messages[0]);
assert.deepEqual(projected.slice(-2), messages.slice(-2));
assert.equal(projected[2].result.value.kind, 'stored-source-ref');
assert.equal(projected[2].result.value.text, undefined);
assert.equal(projected[2].result.value.readWith.name, 'read_result');
assert.equal((await store.read(descriptor.resultRef)).text, source.text);
assert(bytes(projected) <= maxBytes);
await assert.rejects(projectContext({ messages, maxBytes: 1, lookupSource: id => store.resolve(id) }), error => error.code === 'CONTEXT_CAPACITY_EXCEEDED');
console.log(JSON.stringify({
  check: 'bounded-portfolio-runs-and-pure-context-projection', mode: 'fixture', providerCalls: 0,
  cases,
  context: { inputKind: 'constructed-paired-exercise-from-actual-records', beforeBytes, maxBytes, afterBytes: bytes(projected), originalHistoryUnchanged: true, originalSourceUnchanged: true, latestCompleteGroupRetained: true, impossibleCapacity: 'CONTEXT_CAPACITY_EXCEEDED' },
  semanticStatus: 'unreviewed'
}, null, 2));
