// Offline book exercise. Run only when verification has been authorized:
// node examples/ch15/ask-an-assistant.mjs --repo REPO --output OUTPUT_ROOT
// Each variant owns a new project. No existing response project is modified.
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { assertFixedRepository } from '../check-base.mjs';

const args = process.argv.slice(2);
assert.equal(args.length, 4, 'Supply --repo REPO --output OUTPUT_ROOT');
const options = Object.fromEntries([[args[0], args[1]], [args[2], args[3]]]);
assert.deepEqual(Object.keys(options).sort(), ['--output', '--repo']);
const repo = assertFixedRepository(resolve(options['--repo']));
let forbiddenFetchAttempts = 0;
globalThis.fetch = async () => { forbiddenFetchAttempts++; throw new Error('BOOK_OFFLINE_FETCH_FORBIDDEN'); };
const load = name => import(pathToFileURL(join(repo, 'src', name)));
const { createResearchProject, submitResearchTask, workResearchTask, inspectResearchTask, readResearchReport } = await load('research-project.mjs');
const { importProjectSources, loadProjectSources } = await load('project-sources.mjs');
const { CLAIM_COMPARISON_METHOD } = await load('child.mjs');
const { readSpecialistHandoff } = await load('specialist-child.mjs');
const { openSession } = await load('session.mjs');
const sha256 = value => createHash('sha256').update(value).digest('hex');
const call = (id, name, arguments_) => ({ kind: 'calls', calls: [{ id, name, arguments: arguments_ }], usage: null });
const rootId = 'cash-review-1';
const config = {
  schemaVersion: 'research-project@1',
  gateway: { mode: 'fixture', provider: 'local', protocol: 'fixture@1', model: 'book-cash-review' },
  capabilities: ['report', 'child'],
  childMethod: CLAIM_COMPARISON_METHOD,
  allowedTools: ['source_check', 'read_page', 'read_result', 'save_report'],
  limits: { maxRounds: 8, maxTools: 8, timeoutMs: 300000, model: 12, tool: 10 }
};
const question = '核对两份合成材料中关于现金变化的表述。让只读助手比较草稿与口径说明，再保存一份修订说明，区分金额差额、错误收益率推断与缺少费用资料；不更改固定目标，不提出交易建议。';
const files = ['cash-basis.md', 'cash-draft.md'].map(name => fileURLToPath(new URL(name, import.meta.url)));
const inputTexts = await Promise.all(files.map(file => readFile(file, 'utf8')));
// This is only a book-input consistency check, not a source-bound calculation tool.
const fixture = JSON.parse(await readFile(join(repo, 'fixtures/portfolio-rebalance.json'), 'utf8'));
assert.equal(fixture.synthetic, true);
assert(fixture.rows.every(row => row.dataAsOf === '2026-10-01' && row.currency === 'CNY'));
assert.equal(fixture.rows.find(row => row.id === 'cash-current').value, 5000);
assert.equal(fixture.rows.find(row => row.id === 'cash-target').value, 10000);
for (const suffix of ['-current', '-target']) {
  assert.equal(fixture.rows.filter(row => row.id.endsWith(suffix)).reduce((sum, row) => sum + row.value, 0), 100000);
}
assert.match(inputTexts[0], /5000 \+ 15000 - 10000 = 10000/);
assert.match(inputTexts[0], /没有提供费用/);
assert.match(inputTexts[1], /故意包含待核对说法/);
await mkdir(resolve(options['--output']), { recursive: true });
const directory = await mkdtemp(join(resolve(options['--output']), 'book-ch15-'));

async function exercise(variant) {
  const projectDir = join(directory, variant);
  await createResearchProject({ directory: projectDir, config });
  const imported = await importProjectSources({ projectDir, files });
  const basis = imported.catalog.documents.find(document => document.name === 'cash-basis.md');
  const draft = imported.catalog.documents.find(document => document.name === 'cash-draft.md');
  assert(basis && draft);
  assert.equal(imported.catalog.documents.length, 2);
  assert.deepEqual(basis.pages, [inputTexts[0]]);
  assert.deepEqual(draft.pages, [inputTexts[1]]);
  await submitResearchTask({ projectDir, runId: rootId, question, sourceManifestSha256: imported.manifestSha256 });
  const before = await inspectResearchTask({ projectDir, runId: rootId });
  assert.deepEqual(before.run.rootUsage, { model: 0, tool: 0 });

  const calls = [];
  const consumed = [];
  // Only the Child branch emits this variant marker. Main copies the value from
  // the actual handoff; the A/B reports below prove that this data path is used.
  const childMarker = `synthetic-child-${variant}`;
  const gateway = { mode: 'fixture', async next({ messages, reservation }) {
    assert(reservation);
    assert.equal(reservation.rootId, rootId);
    const role = reservation.runId === rootId ? 'main' : 'child';
    calls.push({ role, runId: reservation.runId, rootId: reservation.rootId, modelOrdinal: reservation.modelOrdinal });
    const results = messages.filter(message => message.role === 'tool');
    assert(results.every(message => message.result.status === 'succeeded'));
    if (role === 'child') {
      assert(!results.some(message => message.result.value?.child));
      const read = id => results.find(message => message.result.value?.documentId === id)?.result.value;
      if (!read(basis.id)) return call('child-read-basis', 'read_page', { documentId: basis.id, page: 1 });
      if (!read(draft.id)) return call('child-read-draft', 'read_page', { documentId: draft.id, page: 1 });
      assert.equal(read(basis.id).text, inputTexts[0]);
      assert.equal(read(draft.id).text, inputTexts[1]);
      return { kind: 'final', usage: null, text: JSON.stringify({
        marker: childMarker,
        amountDifferenceCny: 5000,
        returnClaim: 'not-established',
        feesClaim: 'not-established',
        basisSourceId: read(basis.id).sourceId,
        draftSourceId: read(draft.id).sourceId
      }) };
    }

    const handoff = results.find(message => message.callId === 'check-cash-claims')?.result.value;
    if (!handoff) return call('check-cash-claims', 'source_check', {
      question: '只比较两份合成材料中的现金金额差额、收益率与费用说法。保留原来源身份，指出未获支持的推断；不要修改固定目标，也不要保存最终报告。'
    });
    assert.equal(handoff.child.status, 'completed');
    assert.equal(handoff.child.derived, true);
    assert.equal(handoff.child.semanticStatus, 'unreviewed');
    assert.equal(handoff.child.parentRunId, rootId);
    const derived = JSON.parse(handoff.child.summary);
    // Mechanical checks for this fixture do not establish general semantic QA.
    assert.match(derived.marker, /^synthetic-child-[AB]$/);
    assert.equal(derived.amountDifferenceCny, 5000);
    assert.equal(derived.returnClaim, 'not-established');
    assert.equal(derived.feesClaim, 'not-established');
    const original = handoff.sources.find(source => source.sourceId === derived.basisSourceId);
    const disputed = handoff.sources.find(source => source.sourceId === derived.draftSourceId);
    assert.equal(original?.documentId, basis.id);
    assert.equal(disputed?.documentId, draft.id);
    assert.equal(original.text, inputTexts[0]);
    assert.equal(disputed.text, inputTexts[1]);
    assert.match(original.text, /没有提供费用/);
    assert.match(disputed.text, /收益率为100%/);
    consumed.push({ childRunId: handoff.child.runId, marker: derived.marker, sourceIds: [original.sourceId, disputed.sourceId] });
    if (!results.some(message => message.callId === 'save-cash-review')) return call('save-cash-review', 'save_report', {
      text: '# 合成组合现金草稿核对\n\n数据日期2026-10-01，币种CNY，总额100000。现金由5000到固定目标10000，目标金额多5000；目标由教学输入预设。[1]\n\n待核对草稿把金额变化写成收益率100%，并声称目标已经包含费用。[2] 原资料没有提供费用，不能确认费用为零，也不支持把这次目标金额差额解释为期间投资收益。[1]\n\n本页不提出交易建议、不改变原目标。Child 摘要是派生且未经通用语义评审的信息，主任务对照原文后整理本页。\n\n合成交接标记：' + derived.marker,
      sourceIds: [original.sourceId, disputed.sourceId]
    });
    return { kind: 'final', text: '已保存合成草稿核对说明，保留原来源与未知费用边界。', usage: null };
  } };

  const worked = await workResearchTask({ projectDir, runId: rootId, gateway });
  assert.equal(worked.workerStatus, 'settled');
  assert.equal(worked.run.status, 'completed', worked.run.snapshot.code);
  assert.deepEqual(worked.run.rootUsage, { model: 6, tool: 4 });
  assert.equal(calls.filter(item => item.role === 'main').length, 3);
  assert.equal(calls.filter(item => item.role === 'child').length, 3);
  const childIds = [...new Set(calls.filter(item => item.role === 'child').map(item => item.runId))];
  assert.equal(childIds.length, 1);
  assert.notEqual(childIds[0], rootId);
  assert.equal(consumed.length, 2);
  assert(consumed.every(item => item.childRunId === childIds[0] && item.marker === childMarker));
  const state = await inspectResearchTask({ projectDir, runId: rootId });
  assert.equal(state.definition.grantId, before.definition.grantId);
  assert.equal(state.definition.sourceManifestSha256, before.definition.sourceManifestSha256);
  assert.equal(state.run.definition.deadlineAt, before.run.definition.deadlineAt);
  const recorded = state.run.snapshot.messages.find(message => message.callId === 'check-cash-claims').result.value;

  // Reopen the original Session and source manifest after the Worker has closed.
  // No path suggested by the fixture model is used to locate the Child.
  const sources = await loadProjectSources({ projectDir, manifestSha256: state.definition.sourceManifestSha256 });
  const store = await openSession({ directory: join(projectDir, 'sessions', rootId), readOnly: true });
  let child;
  try {
    const reread = await readSpecialistHandoff({
      store, parentRunId: rootId, question: state.run.definition.question,
      documents: sources.catalog.documents.map(document => document.id), documentCatalog: sources.catalog,
      // The original persisted Host configuration also preserves the descriptor
      // serialization used by the Child question in this fixed version.
      method: state.definition.config.childMethod, callId: 'check-cash-claims'
    });
    assert.deepEqual(reread, recorded);
    child = store.inspect(reread.child.runId);
    assert.equal(child.parentRunId, rootId);
    assert.equal(child.rootId, rootId);
    assert.equal(child.definition.grantId, state.definition.grantId);
    assert.deepEqual(child.definition.rootLimits, state.run.definition.rootLimits);
    assert.deepEqual(child.definition.bindings.gateway, state.run.definition.bindings.gateway);
    assert(child.definition.deadlineAt <= state.run.definition.deadlineAt);
    assert.deepEqual(child.definition.config.allowedTools, ['read_page']);
    assert.equal(child.definition.config.requireReport, false);
    assert(!child.definition.bindings.adapters.some(binding => binding.id === 'publication'));
    assert.equal(child.snapshot.messages.filter(message => message.role === 'tool').length, 2);
    assert.equal(reread.sources.length, 2);
    for (const source of reread.sources) {
      const document = sources.catalog.documents.find(item => item.id === source.documentId);
      assert(document);
      assert.equal(source.page, 1);
      assert.equal(source.version, document.version);
      assert.equal(source.text, document.pages[0]);
      assert.equal(source.sha256, sha256(source.text));
      assert.match(source.resultRef, /^result:sha256:[a-f0-9]{64}$/);
    }
  } finally { store.close(); }

  const report = await readResearchReport({ projectDir, runId: rootId });
  assert(report.report.text.includes(childMarker));
  assert.match(report.report.text, /不能确认费用为零/);
  const count = calls.length;
  const repeated = await workResearchTask({ projectDir, runId: rootId, gateway: {
    mode: 'fixture', next() { throw new Error('Terminal work must not dispatch'); }
  } });
  assert.equal(calls.length, count);
  assert.equal(repeated.run.status, 'completed');
  assert.deepEqual(repeated.run.rootUsage, state.run.rootUsage);
  assert.equal((await readResearchReport({ projectDir, runId: rootId })).report.sha256, report.report.sha256);
  return {
    variant, projectDir, rootId, childRunId: child.runId, rootUsage: state.run.rootUsage,
    mainGatewayCalls: 3, childGatewayCalls: 3, consumedMarker: consumed[0].marker,
    sourceIds: consumed[0].sourceIds, originalSourcesReread: true, sameGrantAndRootBudget: true,
    childTools: child.definition.config.allowedTools, reportSha256: report.report.sha256,
    terminalRedrive: 'no-new-calls', semanticStatus: 'unreviewed'
  };
}

const variants = [await exercise('A'), await exercise('B')];
assert.notEqual(variants[0].consumedMarker, variants[1].consumedMarker);
assert.notEqual(variants[0].reportSha256, variants[1].reportSha256);
assert.deepEqual(variants[0].sourceIds, variants[1].sourceIds);
assert.equal(forbiddenFetchAttempts, 0);
const result = {
  check: 'serial-child-second-loop-and-main-consumption', mode: 'fixture', providerCalls: 0,
  directory, variantChangesReport: true, variants,
  notCovered: ['active-child-crash-recovery', 'mixed-call-refusal', 'budget-exhaustion', 'child-failure', 'malicious-source-text', 'general-semantic-quality']
};
await writeFile(join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
