import assert from 'node:assert/strict';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { assertFixedRepository } from '../check-base.mjs';
import { checkPortfolioPair } from '../portfolio-pair.mjs';
const args = process.argv.slice(2);
if (args.length !== 4 || args[0] !== '--repo' || args[2] !== '--output') throw new Error('Usage: node guard-the-pair.mjs --repo REPO --output OUTPUT_ROOT');
const repo = assertFixedRepository(resolve(args[1]));
const { createHookChain } = await import(pathToFileURL(join(repo, 'src/hooks.mjs')));
const { preparePortfolioRebalance } = await import(pathToFileURL(join(repo, 'src/portfolio-rebalance-demo.mjs')));
const { run } = await import(pathToFileURL(join(repo, 'src/runtime.mjs')));
const outcomes = [];
for (const scenario of ['normal', 'cross-category-before-guard', 'cross-category-with-guard']) {
  const acquired = new Map();const rejections = [];
  const hooks = createHookChain({
    before: [({ effective }) => {
      if (effective.name !== 'calculate_change') return;
      const input = effective.arguments;
      const rows = acquired.get(input.resultRef);
      if (!rows) throw new Error('BOOK_ACQUIRED_SOURCE_REQUIRED');
      const review = checkPortfolioPair(rows[input.baselineRow]?.id, rows[input.currentRow]?.id);
      if (!review.accepted) throw new Error(review.code);
      // No patch: the original request is passed unchanged to the normal Host validator.
    }],
    after: [({ result }) => {
      const source = result.value;
      if (source?.sourceId === 'synthetic-fund-portfolio@1:p1' && source.resultRef) acquired.set(source.resultRef, JSON.parse(source.text).rows);
    }],
    failure: [({ result }) => { rejections.push({ status: result.status, dispatched: result.dispatched, error: result.error }); }]
  });
  const prepared = preparePortfolioRebalance();let changed = false;
  const gateway = { mode: 'fixture', async next(input) {
    const proposal = await prepared.gateway.next(input);
    if (scenario !== 'normal' && !changed) {
      const call = proposal.calls?.find(call => call.name === 'calculate_change');
      if (call) { call.arguments.currentRow = 3; changed = true; }
    }
    return proposal;
  } };
  const result = await run({ ...prepared, gateway, ...(scenario === 'cross-category-before-guard' ? {} : { hooks }), requireReport: true, question: 'Check the fixed synthetic portfolio; enforce same-category current-to-target pairs before calculation.', outputRoot: join(resolve(args[3]), scenario) });
  if (scenario === 'normal') { assert.equal(result.status, 'completed');assert(result.receipt); }
  else {
    assert.equal(changed, true);assert.equal(result.status, 'failed');assert.equal(result.receipt, null);
    if (scenario === 'cross-category-with-guard') assert(rejections.some(row => row.status === 'rejected' && row.dispatched === false && row.error === 'BOOK_CATEGORY_MISMATCH'));
  }
  outcomes.push({ scenario, status: result.status, code: result.code, toolsDispatched: result.toolsDispatched, reportSaved: Boolean(result.receipt), rejections, directory: result.directory });
}
assert(outcomes.find(row => row.scenario === 'cross-category-before-guard').toolsDispatched > outcomes.find(row => row.scenario === 'cross-category-with-guard').toolsDispatched);
console.log(JSON.stringify({ check: 'book-owned-pre-dispatch-portfolio-rule', mode: 'fixture', providerCalls: 0, publicSourceModified: false, durableRecoveryAssessed: false, outcomes, semanticStatus: 'unreviewed' }, null, 2));
