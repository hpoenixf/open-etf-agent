import assert from 'node:assert/strict';
import { mkdir, mkdtemp } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { assertFixedRepository } from '../check-base.mjs';
const args = process.argv.slice(2);
if (args.length !== 4 || args[0] !== '--repo' || args[2] !== '--output') throw new Error('Usage: node remember-and-forget.mjs --repo REPO --output OUTPUT_ROOT');
const repo = assertFixedRepository(resolve(args[1]));
const { openMemoryLibrary } = await import(pathToFileURL(join(repo, 'src/memory.mjs')));
const { createMemoryBindings } = await import(pathToFileURL(join(repo, 'src/memory-tools.mjs')));
const { projectMemory } = await import(pathToFileURL(join(repo, 'src/memory-projection.mjs')));
const { sha256 } = await import(pathToFileURL(join(repo, 'src/source.mjs')));
await mkdir(resolve(args[3]), { recursive: true });
const directory = await mkdtemp(join(resolve(args[3]), 'book-memory-'));
const library = await openMemoryLibrary({ directory, writable: true });
const initialText = '合成教学偏好：组合简报先列现金核对，再列类别对照；不改变固定目标，不授权任何交易。';
const revisedText = '合成教学偏好：组合简报先列输入日期与固定目标，再列现金核对；不改变数值和权限。';
const intent = (operation, text, reference) => ({
  explicit: true, libraryId: library.libraryId, operation,
  intentId: 'book-synthetic-' + operation, origin: 'book-synthetic-exercise',
  ...(text !== undefined ? { approvedTextHash: sha256(text) } : {}),
  ...(reference ? { entryId: reference.id, expectedRevision: reference.revision } : {})
});
let report;
try {
  // Exercise-only trusted intents: these are not assertions about a real user's authorization.
  const saveIntent = intent('save', initialText);
  const bindings = createMemoryBindings({ library, intents: [saveIntent] });
  const saveBinding = bindings.find(binding => binding.name === 'memory_save');
  assert.throws(() => saveBinding.validate({ text: initialText, intent: saveIntent }), /intent is not a model argument/);
  assert.throws(() => saveBinding.validate({ text: revisedText }), /No exact trusted Memory intent/);
  saveBinding.validate({ text: initialText });
  const saved = await saveBinding.execute({ text: initialText }, {});
  const first = await library.read(saved.id);
  assert.equal(first.revision, 1);
  assert.equal((await library.search('现金')).length, 1);
  const history = [
    { role: 'user', content: 'Synthetic memory-projection exercise only.' },
    { role: 'assistant', calls: [{ id: 'book-save', name: 'memory_save', arguments: { text: initialText } }] },
    { role: 'tool', callId: 'book-save', result: { callId: 'book-save', status: 'succeeded', value: saved } },
    { role: 'assistant', calls: [{ id: 'book-read', name: 'memory_read', arguments: { id: saved.id } }] },
    { role: 'tool', callId: 'book-read', result: { callId: 'book-read', status: 'succeeded', value: first } }
  ];
  const lookupState = ref => { assert.equal(ref.libraryId, library.libraryId); return library.state(ref.id); };
  const currentView = await projectMemory({ messages: history, lookupState });
  assert.equal(currentView[4].result.value.text, initialText);
  const revised = await library.revise(saved.id, saved.revision, { text: revisedText }, { intent: intent('revise', revisedText, saved) });
  assert.equal(revised.id, saved.id);
  assert.equal(revised.revision, 2);
  await assert.rejects(library.revise(saved.id, saved.revision, { text: initialText }, { intent: intent('revise-stale', initialText, saved) }), /Memory revision conflict/);
  const revisedView = await projectMemory({ messages: history, lookupState });
  assert.equal(revisedView[4].result.value.kind, 'unavailable-memory-projection');
  assert.equal(revisedView[4].result.value.text, undefined);
  assert.equal(revisedView[1].calls[0].arguments.text, '[projected redaction: forgotten or superseded Memory text]');
  const forgotten = await library.forget(revised.id, revised.revision, { intent: intent('forget', undefined, revised) });
  assert.equal(forgotten.revision, 3);
  assert.deepEqual(await library.search('现金'), []);
  assert.deepEqual(await library.list(), []);
  await assert.rejects(library.read(saved.id), /forgotten or unavailable/);
  const finalView = await projectMemory({ messages: history, lookupState });
  assert.equal(finalView[4].result.value.kind, 'unavailable-memory-projection');
  assert.equal(history[4].result.value.text, initialText);
  report = {
    check: 'explicit-synthetic-memory-lifecycle-and-future-input-projection', mode: 'offline', providerCalls: 0,
    directory, libraryId: library.libraryId, entryId: saved.id,
    revisions: { saved: saved.revision, revised: revised.revision, forgotten: forgotten.revision },
    modelSuppliedIntent: 'rejected', unapprovedChangedText: 'rejected', staleRevision: 'rejected',
    futureTypedOldText: 'unavailable', originalHistoryRetained: true,
    physicalErasure: false, alreadyExportedOrSentBytesWithdrawn: false,
    semanticStatus: 'unreviewed'
  };
} finally { await library.close(); }
console.log(JSON.stringify(report, null, 2));
