import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';

const result = JSON.parse(
  await readFile('book-output/ch03-result.json', 'utf8')
);
assert.equal(result.status, 'completed');
const bytes = await readFile(join(result.directory, 'report.md'));
const digest = createHash('sha256').update(bytes).digest('hex');
assert.equal(bytes.length, result.receipt.bytes);
assert.equal(digest, result.receipt.sha256);
console.log('报告字节与本次保存回执相符。');
