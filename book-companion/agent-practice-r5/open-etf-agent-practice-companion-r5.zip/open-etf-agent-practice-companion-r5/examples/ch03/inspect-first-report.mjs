import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';

const input = process.argv[2];
if (!input) throw new Error('Usage: node inspect-first-report.mjs RESULT_JSON');
const result = JSON.parse(await readFile(input, 'utf8'));
assert.equal(result.caseId, 'portfolio-rebalance');
assert.equal(result.mode, 'fixture');
assert.equal(result.status, 'completed');
const directory = resolve(result.directory);
const report = await readFile(join(directory, 'report.md'));
const manifest = JSON.parse(await readFile(join(directory, 'manifest.json'), 'utf8'));
const digest = createHash('sha256').update(report).digest('hex');
assert.equal(digest, result.receipt.sha256);
assert.equal(report.length, result.receipt.bytes);
assert.equal(manifest.receipt.revisionId, result.receipt.revisionId);
assert.equal(manifest.sources.length, 1);
assert.equal(manifest.calculations.length, 6);
assert.equal(result.receipt.attachmentIds.length, 7);
console.log(JSON.stringify({
  check: 'first-report-readback',
  status: 'passed',
  reportBytesMatch: true,
  sourceCount: manifest.sources.length,
  calculationCount: manifest.calculations.length,
  attachmentCount: result.receipt.attachmentIds.length,
  semanticStatus: 'unreviewed',
  providerCallsInThisCheck: 0
}, null, 2));
