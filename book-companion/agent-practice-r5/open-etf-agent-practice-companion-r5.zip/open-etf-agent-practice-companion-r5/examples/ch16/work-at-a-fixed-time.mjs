// Offline book exercise; no cron, background service, market feed, or provider.
// node examples/ch16/work-at-a-fixed-time.mjs --repo REPO --output OUTPUT_ROOT
// Part 1 uses a real near-future instant. Part 2 uses isolated Session clocks,
// never the system clock, and never dispatches a Worker under simulated time.
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, readdir, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { setTimeout as sleep } from 'node:timers/promises';
import { assertFixedRepository } from '../check-base.mjs';

const args = process.argv.slice(2);
assert.equal(args.length, 4, 'Supply --repo REPO --output OUTPUT_ROOT');
const options = Object.fromEntries([[args[0], args[1]], [args[2], args[3]]]);
assert.deepEqual(Object.keys(options).sort(), ['--output', '--repo']);
const repo = assertFixedRepository(resolve(options['--repo']));
let forbiddenFetchAttempts = 0;
globalThis.fetch = async () => { forbiddenFetchAttempts++; throw new Error('BOOK_OFFLINE_FETCH_FORBIDDEN'); };
const load = name => import(pathToFileURL(join(repo, 'src', name)));
const { createResearchProject, submitResearchTask, workResearchTask, inspectResearchTask, readResearchReport, validateResearchConfig } = await load('research-project.mjs');
const { importProjectSources } = await load('project-sources.mjs');
const { openSession } = await load('session.mjs');
const { confirmScheduledRun, materializeScheduledRun } = await load('runtime.mjs');
const { SCHEDULE_PROFILE, SCHEDULE_COMPOSITION_BINDING, scheduleRunId } = await load('schedule.mjs');
const { PUBLICATION_BINDING } = await load('publication.mjs');
const { createTaskTime, taskTimeMessage } = await load('temporal.mjs');
const call = (id, name, arguments_) => ({ kind: 'calls', calls: [{ id, name, arguments: arguments_ }], usage: null });
const config = {
  schemaVersion: 'research-project@1',
  gateway: { mode: 'fixture', provider: 'local', protocol: 'fixture@1', model: 'book-cash-at-time' },
  capabilities: ['report', 'schedule', 'task-time'],
  timeZone: 'Asia/Shanghai',
  allowedTools: ['read_page', 'read_result', 'save_report'],
  limits: { maxRounds: 6, maxTools: 5, timeoutMs: 60000, model: 6, tool: 5 }
};
// Unsupported pairs are configuration errors, not a reason to alter chapter 10.
for (const [pair, code] of [
  [['response', 'child'], 'PROJECT_RESPONSE_CHILD_UNSUPPORTED'],
  [['schedule', 'child'], 'PROJECT_SCHEDULE_CHILD_UNSUPPORTED'],
  [['response', 'schedule'], 'PROJECT_RESPONSE_SCHEDULE_UNSUPPORTED']
]) {
  assert.throws(() => validateResearchConfig({ ...config, capabilities: ['report', 'task-time', ...pair] }), error => error.code === code);
}
const anchorInstant = '2026-10-02T00:30:00.000Z';
const shanghai = createTaskTime({ anchorInstant, timeZone: 'Asia/Shanghai' });
const losAngeles = createTaskTime({ anchorInstant, timeZone: 'America/Los_Angeles' });
assert.equal(shanghai.taskDate, '2026-10-02');
assert.equal(shanghai.yesterday, '2026-10-01');
assert.equal(shanghai.tomorrow, '2026-10-03');
assert.equal(losAngeles.taskDate, '2026-10-01');
assert.throws(() => createTaskTime({ anchorInstant: '2026-10-02T08:30:00+08:00', timeZone: 'Asia/Shanghai' }), error => error.code === 'INVALID_TASK_ANCHOR');

await mkdir(resolve(options['--output']), { recursive: true });
const directory = await mkdtemp(join(resolve(options['--output']), 'book-ch16-'));
const projectDir = join(directory, 'real-near-future');
await createResearchProject({ directory: projectDir, config });
const sourcePath = fileURLToPath(new URL('cash-basis.md', import.meta.url));
const sourceText = await readFile(sourcePath, 'utf8');
assert.match(sourceText, /数据时点2026-10-01/);
assert.match(sourceText, /5000 \+ 15000 - 10000 = 10000/);
const imported = await importProjectSources({ projectDir, files: [sourcePath] });
const documentId = imported.catalog.documents[0].id;
const taskId = 'cash-at-time-1';
const question = '在已确认时点整理现有合成现金说明。分开标注固定任务日期与2026-10-01资料日期，不声称取得实时行情，不更改固定目标，不提出交易建议。';
// Imports and project creation finish before sampling this short real window.
// If confirmation itself is too slow, the API fails. We do not silently move due.
const dueMs = Date.now() + 3000;
const schedule = {
  scheduleId: 'cash-note-once-1', definitionRevision: 1,
  scheduledInstant: new Date(dueMs).toISOString(), timeZone: 'Asia/Shanghai', maxLatenessMs: 20000
};
const fixedTaskTime = createTaskTime({ anchorInstant: schedule.scheduledInstant, timeZone: schedule.timeZone });
let gatewayCalls = 0;
const dispatchTimes = [];
const gateway = { mode: 'fixture', async next({ messages, reservation }) {
  gatewayCalls++;
  dispatchTimes.push(Date.now());
  assert(dispatchTimes.at(-1) >= dueMs, 'A scheduled model call must not start before due.');
  assert.equal(reservation.runId, scheduleRunId(schedule));
  assert.equal(reservation.rootId, reservation.runId);
  assert.deepEqual(messages[1], taskTimeMessage(fixedTaskTime));
  const results = messages.filter(message => message.role === 'tool');
  assert(results.every(message => message.result.status === 'succeeded'));
  const source = results.find(message => message.callId === 'read-cash-at-time')?.result.value;
  if (!source) return call('read-cash-at-time', 'read_page', { documentId, page: 1 });
  assert.equal(source.text, sourceText);
  if (!results.some(message => message.callId === 'save-cash-at-time')) return call('save-cash-at-time', 'save_report', {
    text: '# 合成现金说明的定时整理\n\n固定任务日期：' + fixedTaskTime.taskDate + '（' + fixedTaskTime.timeZone + '）。固定解释时刻：' + fixedTaskTime.anchorInstant + '。\n\n金额来自2026-10-01的合成快照，不是任务执行日的实时余额，没有取得更新资料。[1]\n\n当前现金5000 CNY，固定目标10000 CNY；总额100000 CNY。给定金额之间的关系为5000 + 15000 - 10000 = 10000，目标由教学输入预设。没有提供费用、税费、滑点或交易单位资料，未知不等于零。[1]\n\n本页不提出交易建议。本次是一次显式到期调用，不是后台周期研究。',
    sourceIds: [source.sourceId]
  });
  return { kind: 'final', text: '已保存现有合成资料的定时整理，任务日期不改变资料日期。', usage: null };
} };

const confirmed = await submitResearchTask({ projectDir, runId: taskId, question, sourceManifestSha256: imported.manifestSha256, schedule });
assert.equal(confirmed.state, 'confirmed');
assert.equal(confirmed.runId, null);
assert.equal(confirmed.run, null);
assert(confirmed.confirmedAt < dueMs);
assert.equal(gatewayCalls, 0);
const before = await inspectResearchTask({ projectDir, runId: taskId });
assert.equal(before.run, null);
assert.equal(before.schedule.state, 'confirmed');
assert.deepEqual(before.definition.taskTime, fixedTaskTime);

const first = await workResearchTask({ projectDir, runId: taskId, gateway });
let worked = first;
let requestedWaitMs = 0;
if (first.state === 'not-due') {
  assert.equal(first.run, null);
  assert.equal(gatewayCalls, 0);
  // A short foreground wait is not a daemon, and no clock is changed.
  requestedWaitMs = Math.max(0, dueMs - Date.now() + 20);
  assert(requestedWaitMs <= 3020);
  if (requestedWaitMs) await sleep(requestedWaitMs);
  worked = await workResearchTask({ projectDir, runId: taskId, gateway });
} else {
  // Slow setup can cross due before the first work call. Do not label it early.
  assert.equal(first.run?.status, 'completed', JSON.stringify(first));
}
assert.equal(worked.workerStatus, 'settled');
assert.equal(worked.run.status, 'completed', JSON.stringify(worked));
assert.equal(gatewayCalls, 3);
assert.deepEqual(worked.run.rootUsage, { model: 3, tool: 2 });
assert.equal(worked.run.runId, scheduleRunId(schedule));
assert.notEqual(worked.run.runId, taskId);
assert.equal(worked.run.definition.deadlineAt, dueMs + config.limits.timeoutMs);
assert.deepEqual(worked.run.definition.config.taskTime, fixedTaskTime);
const report = await readResearchReport({ projectDir, runId: taskId });
assert.match(report.report.text, /2026-10-01/);
assert.match(report.report.text, /没有取得更新资料/);
assert(report.report.text.includes(fixedTaskTime.taskDate));
const repeated = await workResearchTask({ projectDir, runId: taskId, gateway: {
  mode: 'fixture', next() { throw new Error('Repeated completed occurrence must not dispatch'); }
} });
assert.equal(repeated.run.runId, worked.run.runId);
assert.equal(repeated.run.directory, worked.run.directory);
assert.deepEqual(repeated.run.rootUsage, worked.run.rootUsage);
assert.equal((await readResearchReport({ projectDir, runId: taskId })).report.sha256, report.report.sha256);
const repeatedConfirmation = await submitResearchTask({ projectDir, runId: taskId, question, sourceManifestSha256: imported.manifestSha256, schedule });
assert.deepEqual(repeatedConfirmation.reference, confirmed.reference);
assert.equal(repeatedConfirmation.runId, worked.run.runId);
assert.equal(gatewayCalls, 3);
assert.equal((await readdir(join(projectDir, 'outputs'))).filter(name => name.startsWith('run-')).length, 1);
const readonly = await openSession({ directory: join(projectDir, 'sessions', taskId), profile: SCHEDULE_PROFILE, readOnly: true });
let occurrence;
try {
  occurrence = readonly.inspectSchedule(confirmed.reference);
  assert.equal(occurrence.state, 'materialized');
  assert.equal(occurrence.run.status, 'completed');
  assert.equal(occurrence.runId, worked.run.runId);
  assert(occurrence.materializedAt >= dueMs);
  assert(occurrence.materializedAt < dueMs + schedule.maxLatenessMs);
} finally { readonly.close(); }

// These are explicitly simulated materialization checks, not Worker runs and
// not a claim that the real process lived through a different calendar day.
const simulatedDue = Date.parse(anchorInstant);
let simulatedGatewayCalls = 0;
const simulated = [];
async function scenario(name, check) {
  const sessionDir = join(directory, 'simulated-' + name);
  let now = simulatedDue - 100;
  const store = await openSession({ directory: sessionDir, profile: SCHEDULE_PROFILE, clock: () => now });
  const localSchedule = {
    scheduleId: 'book-' + name, definitionRevision: 1,
    scheduledInstant: anchorInstant, timeZone: 'Asia/Shanghai', maxLatenessMs: 20000
  };
  const runtimeOptions = {
    question, documentCatalog: imported.catalog, allowedDocuments: [documentId],
    allowedTools: ['read_page', 'read_result', 'save_report'], requireReport: true, publication: true,
    outputRoot: join(sessionDir, 'runs'), limits: { maxRounds: 6, maxTools: 5, timeoutMs: 60000 },
    gateway: { mode: 'fixture', next() { simulatedGatewayCalls++; throw new Error('Simulation must not dispatch a model'); } },
    durable: {
      store, grantId: 'book-grant-' + name, rootLimits: { model: 6, tool: 5 },
      bindings: {
        gateway: { mode: 'fixture', provider: 'local', protocol: 'fixture@1', model: 'book-cash-schedule-boundary', version: '1' },
        plugins: [], adapters: [PUBLICATION_BINDING, SCHEDULE_COMPOSITION_BINDING]
      }
    }
  };
  try {
    const confirmation = await confirmScheduledRun(runtimeOptions, localSchedule);
    assert.equal(confirmation.state, 'confirmed');
    assert.equal(confirmation.run, null);
    const assertNoRun = () => assert.throws(() => store.inspect(scheduleRunId(localSchedule)), error => error.code === 'UNKNOWN_RUN');
    assertNoRun();
    const facts = await check({
      store, runtimeOptions, localSchedule, confirmation, assertNoRun,
      setOffset: offset => { now = simulatedDue + offset; },
      materialize: () => materializeScheduledRun(runtimeOptions, confirmation.reference)
    });
    assert.equal(simulatedGatewayCalls, 0);
    simulated.push({ name, clock: 'simulated-session-clock', workerExecuted: false, ...facts });
  } finally { store.close(); }
}

await scenario('due-and-retry', async f => {
  f.setOffset(-1);
  assert.equal((await f.materialize()).state, 'not-due');
  f.assertNoRun();
  // not-due is an observation, not a replacement for durable confirmed state.
  assert.equal(f.store.inspectSchedule(f.confirmation.reference).state, 'confirmed');
  f.setOffset(0);
  const first = await f.materialize();
  assert.equal(first.state, 'materialized');
  assert.equal(first.run.definition.deadlineAt, simulatedDue + 60000);
  assert.deepEqual(first.run.definition.config.taskTime, shanghai);
  assert.deepEqual(first.run.rootUsage, { model: 0, tool: 0 });
  f.setOffset(60001);
  assert.deepEqual(await f.materialize(), first);
  assert.deepEqual(await confirmScheduledRun(f.runtimeOptions, f.localSchedule), first);
  // The already materialized Run checks its task-time binding first.
  await assert.rejects(confirmScheduledRun(f.runtimeOptions, { ...f.localSchedule, timeZone: 'UTC' }), error => error.code === 'RUN_BINDINGS_MISMATCH');
  assert.throws(() => materializeScheduledRun(f.runtimeOptions, { ...f.confirmation.reference, confirmationHash: '0'.repeat(64) }), error => error.code === 'SCHEDULE_BINDING_MISMATCH');
  return { beforeDue: 'not-due', atDue: 'materialized', duplicateAfterWindow: 'same-run', deadlineAt: first.run.definition.deadlineAt, runId: first.runId, changedBinding: 'rejected' };
});
await scenario('last-allowed-ms', async f => {
  f.setOffset(19999);
  const value = await f.materialize();
  assert.equal(value.state, 'materialized');
  assert.equal(value.materializedAt, simulatedDue + 19999);
  assert.equal(value.run.definition.deadlineAt, simulatedDue + 60000);
  return { offsetMs: 19999, state: value.state, remainingDeadlineMs: 40001 };
});
await scenario('exclusive-end', async f => {
  f.setOffset(20000);
  const value = await f.materialize();
  assert.equal(value.state, 'missed');
  f.assertNoRun();
  f.setOffset(0);
  assert.deepEqual(await f.materialize(), value);
  f.assertNoRun();
  return { offsetMs: 20000, state: value.state, clockRewind: 'still-missed', runCreated: false };
});
await scenario('late-first-confirm', async f => {
  f.setOffset(0);
  const lateSchedule = { ...f.localSchedule, scheduleId: 'book-new-late-confirmation' };
  await assert.rejects(confirmScheduledRun(f.runtimeOptions, lateSchedule), error => error.code === 'SCHEDULE_CONFIRMATION_TOO_LATE');
  assert.throws(() => f.store.inspect(scheduleRunId(lateSchedule)), error => error.code === 'UNKNOWN_RUN');
  f.assertNoRun();
  return { newConfirmationAtDue: 'SCHEDULE_CONFIRMATION_TOO_LATE', runCreated: false };
});
for (const revoke of [false, true]) {
  await scenario(revoke ? 'revoke-before' : 'cancel-before', async f => {
    const value = f.store.cancelSchedule(f.confirmation.reference, { revoke });
    assert.equal(value.state, revoke ? 'revoked' : 'cancelled');
    f.assertNoRun();
    f.setOffset(0);
    assert.deepEqual(await f.materialize(), value);
    assert.deepEqual(await confirmScheduledRun(f.runtimeOptions, f.localSchedule), value);
    f.assertNoRun();
    return { state: value.state, replay: 'does-not-resurrect', runCreated: false };
  });
}
await scenario('cancel-after', async f => {
  f.setOffset(0);
  const first = await f.materialize();
  const cancelled = f.store.cancelSchedule(f.confirmation.reference);
  assert.equal(cancelled.state, 'cancelled');
  assert.equal(cancelled.runId, first.runId);
  assert.equal(cancelled.materializedAt, first.materializedAt);
  assert.equal(cancelled.run.status, 'cancelled');
  assert.deepEqual(cancelled.run.rootUsage, first.run.rootUsage);
  assert.equal(cancelled.run.definition.deadlineAt, first.run.definition.deadlineAt);
  f.setOffset(20001);
  assert.deepEqual(await f.materialize(), cancelled);
  return { state: cancelled.state, originalRunLinkRetained: true, rootUsage: cancelled.run.rootUsage };
});

assert.equal(gatewayCalls, 3);
assert.equal(simulatedGatewayCalls, 0);
assert.equal(forbiddenFetchAttempts, 0);
const result = {
  check: 'one-shot-due-project-and-simulated-session-boundaries', directory,
  mode: 'fixture', providerCalls: 0, backgroundSchedulerStarted: false, systemClockChanged: false,
  calendarExamples: { shanghai, losAngeles }, unsupportedCapabilityPairs: 'rejected',
  actual: {
    projectDir, taskId, runId: worked.run.runId, schedule,
    confirmedAt: confirmed.confirmedAt, materializedAt: occurrence.materializedAt,
    firstWork: first.state === 'not-due' ? 'not-due' : 'already-due', requestedWaitMs,
    dispatchTimes, gatewayCalls, rootUsage: worked.run.rootUsage, fixedTaskTime,
    dataDate: '2026-10-01', deadlineAt: worked.run.definition.deadlineAt,
    repeat: 'same-run-no-new-calls', reportSha256: report.report.sha256, semanticStatus: 'unreviewed'
  },
  simulatedGatewayCalls, simulated,
  notCovered: ['concurrent-process-wakes', 'process-crash-during-materialization', 'cancel-during-unknown-remote-effect', 'worker-after-original-deadline', 'DST-natural-language-parsing', 'market-data-refresh', 'background-cron']
};
await writeFile(join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
