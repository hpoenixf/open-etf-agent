// Book-owned business rule, deliberately limited to the six fixed teaching buckets.
const buckets = new Set(['dividend', 'overseas', 'bond', 'gold', 'ai', 'cash']);
export function checkPortfolioPair(baselineId, currentId) {
  if (typeof baselineId !== 'string' || typeof currentId !== 'string') return { accepted: false, code: 'BOOK_PAIR_ID_REQUIRED' };
  const baseline = /^(.*)-current$/.exec(baselineId);
  const current = /^(.*)-target$/.exec(currentId);
  if (!baseline || !current || !buckets.has(baseline[1]) || !buckets.has(current[1])) return { accepted: false, code: 'BOOK_PAIR_ROLE_UNKNOWN' };
  if (baseline[1] !== current[1]) return { accepted: false, code: 'BOOK_CATEGORY_MISMATCH' };
  return { accepted: true, bucket: baseline[1] };
}
