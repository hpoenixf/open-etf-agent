import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { assertFixedRepository } from '../check-base.mjs';
import { checkPortfolioPair } from '../portfolio-pair.mjs';
const args = process.argv.slice(2);
if (args.length !== 4 || args[0] !== '--repo' || args[2] !== '--result') throw new Error('Usage: node check-the-task.mjs --repo REPO --result CH03_RESULT_JSON');
const repo = assertFixedRepository(resolve(args[1]));
const { createResultStore } = await import(pathToFileURL(join(repo, 'src/results.mjs')));
const { calculateChange } = await import(pathToFileURL(join(repo, 'src/calculation.mjs')));
const result = JSON.parse(await readFile(resolve(args[3]), 'utf8'));
assert.equal(result.caseId, 'portfolio-rebalance');
assert.equal(result.status, 'completed');
const store = await createResultStore({ directory: result.directory, readOnly: true });
const descriptors = await store.listCalculations();
assert.equal(descriptors.length, 6);
const byBucket = new Map();
for (const descriptor of descriptors) {
  const calculation = await store.readCalculation(descriptor.resultRef);
  const pair = checkPortfolioPair(calculation.binding.baseline.rowId, calculation.binding.current.rowId);
  assert.equal(pair.accepted, true);
  assert(!byBucket.has(pair.bucket));
  assert.equal(calculation.binding.currency, 'CNY');
  assert.equal(calculation.binding.dataAsOf, '2026-10-01');
  byBucket.set(pair.bucket, calculation);
}
const expectedDifferences = { dividend: -10000, overseas: 5000, bond: -5000, gold: 0, ai: 5000, cash: 5000 };
for (const [bucket, expected] of Object.entries(expectedDifferences)) assert.equal(byBucket.get(bucket)?.difference, expected);
const calculations = [...byBucket.values()];
assert.equal(calculations.reduce((sum, calculation) => sum + calculation.inputs.baseline, 0), 100000);
assert.equal(calculations.reduce((sum, calculation) => sum + calculation.inputs.current, 0), 100000);
const noncash = [...byBucket].filter(([bucket]) => bucket !== 'cash').map(([, calculation]) => calculation);
const decreases = noncash.reduce((sum, calculation) => sum + Math.max(0, -calculation.difference), 0);
const increases = noncash.reduce((sum, calculation) => sum + Math.max(0, calculation.difference), 0);
const cash = byBucket.get('cash');
assert.equal(decreases, 15000);assert.equal(increases, 10000);
assert.equal(cash.inputs.baseline + decreases - increases, cash.inputs.current);

// A real available source resolution and valid arithmetic are still the wrong business pair.
const sourceRef = byBucket.get('dividend').binding.sourceRef;
const cross = await store.resolveComparison({ resultRef: sourceRef, selection: { offset: 0, limit: 12 }, baselineRow: 0, currentRow: 3 });
assert.equal(cross.available, true);
const crossCalculation = calculateChange(cross.inputs, cross.binding);
assert.equal(crossCalculation.difference, -15000);
const crossReview = checkPortfolioPair(crossCalculation.binding.baseline.rowId, crossCalculation.binding.current.rowId);
assert.deepEqual(crossReview, { accepted: false, code: 'BOOK_CATEGORY_MISMATCH' });
console.log(JSON.stringify({
  check: 'fixed-portfolio-business-checks', mode: 'offline-read-only', providerCalls: 0, writesToOriginalRun: false,
  pairedCategoriesVerified: byBucket.size, currentTotal: 100000, targetTotal: 100000,
  decreases, increases, cashConservation: true,
  negativeCase: { foundationAccepted: cross.available, arithmeticDifference: crossCalculation.difference, businessReview: crossReview },
  allProseClaims: 'manual-review-required', financialSuitability: 'not-assessed',
  semanticStatus: 'unreviewed', scope: 'Narrow deterministic business checks, not overall investment or model quality certification.'
}, null, 2));
