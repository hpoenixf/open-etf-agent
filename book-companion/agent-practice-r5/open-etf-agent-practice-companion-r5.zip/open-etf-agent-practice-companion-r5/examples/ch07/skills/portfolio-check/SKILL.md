---
name: portfolio-check
description: Check one synthetic portfolio against human-fixed targets while preserving original rows, units, dates, and cash conservation.
---

# 合成组合核对方法

本方法只用于本书同一份合成组合研究，不产生目标权重或投资建议，不授权联网、交易或读取更多文件。

1. 取得原始快照后，检查币种、单位、日期、合成标记及六类项目。
2. 每次比较同一类别的 current 行与 target 行；不能只因为单位和日期相同，就把不同类别配成一组。
3. 从真实取得的来源引用和完整所需选区调用计算工具；不把凭记忆抄写的数字冒充原始行绑定。
4. 金额差额使用 target 减 current；权重偏差使用 current 减 target，并以百分点说明。
5. 核对当前总额与目标总额均为100000 CNY。核对期初现金5000加非现金减少15000减非现金增加10000，得到目标现金10000 CNY。现金行属于储备变化，不是市场买单。
6. 保留六份来源绑定计算CSV；汇总表是它们的派生展示，不取代原计算记录。
7. 报告写明固定目标由教学任务给定，未计入费用、税费、滑点与最小交易单位，没有提交交易。
8. 读过本方法不等于已经正确采用。交付前逐项检查实际工具记录、报告与附件，保留未解决的问题。
