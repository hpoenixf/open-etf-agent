import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { assertFixedRepository } from '../check-base.mjs';

const args = process.argv.slice(2);
if (args.length !== 4 || args[0] !== '--repo' || args[2] !== '--output') {
  throw new Error('Usage: node reuse-the-method.mjs --repo REPO --output OUTPUT_ROOT');
}
const repo = assertFixedRepository(resolve(args[1]));
const { createSkillCatalog } = await import(pathToFileURL(join(repo, 'src/skills.mjs')));
const { preparePortfolioRebalance } = await import(pathToFileURL(join(repo, 'src/portfolio-rebalance-demo.mjs')));
const { run } = await import(pathToFileURL(join(repo, 'src/runtime.mjs')));
const catalog = await createSkillCatalog({ root: fileURLToPath(new URL('./skills', import.meta.url)) });
assert.equal(catalog.list().length, 1);
assert.equal(catalog.list()[0].text, undefined);
await assert.rejects(catalog.resource('portfolio-check', '../outside.txt'), /Unsafe resource path/);
const original = preparePortfolioRebalance();
const exact = (value, fields) => assert.deepEqual(Object.keys(value).sort(), [...fields].sort());
const extensions = [...original.extensions, {
  name: 'list_book_methods', description: 'List explicitly enabled local method metadata, without granting permissions.',
  parameters: { type: 'object', properties: {}, additionalProperties: false },
  validate(args) { exact(args, []); },
  execute: async () => ({ methods: catalog.list() })
}, {
  name: 'read_book_method', description: 'Read one enabled book method as data. Loading does not prove adoption or grant tools.',
  parameters: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'], additionalProperties: false },
  methodResult: true,
  validate(args) { exact(args, ['id']); assert.equal(typeof args.id, 'string'); },
  execute: async ({ id }) => catalog.read(id)
}];
let method;
let turn = 0;
const calls = [];
const gateway = {
  mode: 'fixture',
  async next(input) {
    const results = input.messages.filter(message => message.role === 'tool').map(message => message.result);
    assert(results.every(result => result.status === 'succeeded'));
    let proposal;
    if (++turn === 1) proposal = { kind: 'calls', calls: [{ id: 'book-method-list', name: 'list_book_methods', arguments: {} }] };
    else if (turn === 2) {
      assert.equal(results[0].value.methods[0].id, 'portfolio-check');
      proposal = { kind: 'calls', calls: [{ id: 'book-method-read', name: 'read_book_method', arguments: { id: results[0].value.methods[0].id } }] };
    } else {
      method ??= results.find(result => result.callId === 'book-method-read')?.value;
      assert.equal(method?.id, 'portfolio-check');
      assert.equal(method.sha256, createHash('sha256').update(method.text).digest('hex'));
      proposal = await original.gateway.next(input);
      for (const call of proposal.calls ?? []) {
        if (call.name === 'save_report') call.arguments.text += `\n\n## 本次读取的方法\n\n${method.name}；版本${method.version}。方法已经实际读取并记录，不代表模型采用效果通过语义审查。`;
      }
    }
    calls.push(...(proposal.calls ?? []).map(call => call.name));
    return proposal;
  }
};
const result = await run({
  question: 'Load the explicitly enabled synthetic portfolio checking method, then compare the fixed original rows and save the same portfolio report and CSV evidence. Do not recommend investments or trade.',
  gateway, extensions,
  allowedTools: [...original.allowedTools, 'list_book_methods', 'read_book_method'],
  limits: { maxRounds: 7, maxTools: 18 },
  requireReport: true, outputRoot: resolve(args[3])
});
assert.equal(result.status, 'completed');
const manifest = JSON.parse(await readFile(join(result.directory, 'manifest.json'), 'utf8'));
assert.equal(manifest.methods.length, 1);
assert.deepEqual(manifest.methods[0], method);
assert.equal(manifest.sources.length, 1);
assert.equal(manifest.calculations.length, 6);
assert.equal(manifest.artifacts.attachments.length, 7);
assert.deepEqual(calls.slice(0, 3), ['list_book_methods', 'read_book_method', 'read_portfolio_fixture']);
console.log(JSON.stringify({
  check: 'method-loading-before-the-original-portfolio-run', mode: 'fixture', providerCalls: 0,
  method: { id: method.id, name: method.name, version: method.version, sha256: method.sha256 },
  metadataIncludesBody: false, outOfScopeResourcePath: 'rejected',
  calls, status: result.status, rounds: result.rounds, toolsDispatched: result.toolsDispatched,
  directory: result.directory, receipt: result.receipt,
  semanticStatus: 'unreviewed', adoptionStatus: 'not-assessed'
}, null, 2));
