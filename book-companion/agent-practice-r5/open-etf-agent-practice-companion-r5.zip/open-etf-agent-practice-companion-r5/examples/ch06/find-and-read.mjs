import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { assertFixedRepository } from '../check-base.mjs';

const args = process.argv.slice(2);
if (args.length !== 4 || args[0] !== '--repo' || args[2] !== '--output') {
  throw new Error('Usage: node find-and-read.mjs --repo REPO --output OUTPUT_ROOT');
}
const repo = assertFixedRepository(resolve(args[1]));
const { searchPages } = await import(pathToFileURL(join(repo, 'src/retrieval.mjs')));
const { run } = await import(pathToFileURL(join(repo, 'src/runtime.mjs')));
const catalog = JSON.parse(await readFile(new URL('./research-notes.json', import.meta.url), 'utf8'));
const grant = ['portfolio-policy', 'portfolio-revision'];
const search = query => searchPages({ query, documents: catalog.documents, allowedDocuments: grant, limit: 2 });
assert.deepEqual(search('现金').map(hit => hit.documentId), grant);
assert.deepEqual(search('备用金'), []);
const extensions = [{
  name: 'search_book_pages',
  description: 'Find lexical candidates in the two explicitly allowed synthetic book documents. Hits are not acquired sources.',
  parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'], additionalProperties: false },
  validate(args) { assert.deepEqual(Object.keys(args), ['query']); assert.equal(typeof args.query, 'string'); },
  async execute({ query }) { return { candidates: search(query), acquired: false }; }
}];
let sequence = 0;
let cursor = 0;
let reread = false;
let saved = false;
const gateway = {
  mode: 'fixture',
  async next({ messages }) {
    const results = messages.filter(message => message.role === 'tool').map(message => message.result);
    assert(results.every(result => result.status === 'succeeded'));
    const call = (name, arguments_) => ({ kind: 'calls', calls: [{ id: `book-search-${++sequence}`, name, arguments: arguments_ }] });
    if (!results.length) return call('search_book_pages', { query: '现金' });
    const candidates = results[0].value.candidates;
    if (cursor < candidates.length) {
      const hit = candidates[cursor++];
      return call('read_page', { documentId: hit.documentId, page: hit.page });
    }
    const sources = [...new Map(results.map(result => result.value).filter(value => value?.sourceId && value?.resultRef).map(source => [source.sourceId, source])).values()];
    if (!reread) { reread = true; return call('read_result', { resultRef: sources[0].resultRef }); }
    if (!saved) {
      saved = true;
      return call('save_report', {
        text: '# 合成组合现金资料摘录\n\n离线教学练习，只展示获准资料的检索、读取与原文回读，不生成新的投资判断。\n\n' + sources.map((source, index) => `## 资料${index + 1}\n\n${source.text}\n\n来源[${index + 1}]`).join('\n\n'),
        sourceIds: sources.map(source => source.sourceId)
      });
    }
    assert(results.some(result => result.value?.fileId));
    return { kind: 'final', text: 'Allowed original excerpts saved. Semantic quality remains unreviewed.' };
  }
};
const result = await run({
  question: 'Find and read the allowed synthetic notes about the existing portfolio cash target. Preserve originals and save an excerpt report.',
  gateway,
  extensions,
  documentCatalog: catalog,
  allowedDocuments: grant,
  allowedTools: ['search_book_pages', 'read_page', 'read_result', 'save_report'],
  requireReport: true,
  limits: { maxRounds: 8, maxTools: 8 },
  outputRoot: resolve(args[3])
});
assert.equal(result.status, 'completed');
const manifest = JSON.parse(await readFile(join(result.directory, 'manifest.json'), 'utf8'));
assert.equal(manifest.sources.length, 2);
assert(manifest.sources.every(source => grant.includes(source.documentId)));
const report = await readFile(join(result.directory, 'report.md'), 'utf8');
assert(!report.includes('12000'));
console.log(JSON.stringify({
  check: 'scoped-lexical-search-and-reread',
  mode: 'fixture', providerCalls: 0,
  query: '现金', candidates: search('现金'),
  synonymQuery: { query: '备用金', candidates: search('备用金') },
  excludedDocument: 'meeting-draft',
  sources: manifest.sources.map(source => ({ documentId: source.documentId, version: source.version, page: source.page })),
  status: result.status, directory: result.directory, receipt: result.receipt,
  semanticStatus: 'unreviewed'
}, null, 2));
