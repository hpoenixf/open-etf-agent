import fs from 'node:fs';
import path from 'node:path';

// Teaching data adapted from the project's synthetic Atlas Notes example.
// A scripted decision function is used. No model or network request is made.
const mode = process.argv[2] ?? 'normal';
if (!['normal', 'missing-b', 'early-finish', 'forbidden'].includes(mode)) {
  throw new Error('UNKNOWN_MODE');
}
const directory = fs.mkdtempSync(path.join(process.cwd(), 'tiny-agent-'));
const documents = {
  A: { version: 'A-2026-01', formats: ['CSV'], maxRows: 120, online: true },
  B: { version: 'B-2026-02', formats: ['CSV', 'Markdown'], maxRows: 300, online: true },
};
for (const [id, document] of Object.entries(documents)) {
  if (mode === 'missing-b' && id === 'B') continue;
  fs.writeFileSync(path.join(directory, `${id}.json`), JSON.stringify(document));
}

const history = [];
let saved = null;
function dispatch(proposal) {
  if (proposal.name === 'read') {
    const id = proposal.args?.id;
    if (!['A', 'B'].includes(id)) throw new Error('SOURCE_NOT_ALLOWED');
    const filename = path.join(directory, `${id}.json`);
    if (!fs.existsSync(filename)) return { id, ok: false, reason: 'SOURCE_MISSING' };
    return { id, ok: true, document: JSON.parse(fs.readFileSync(filename, 'utf8')) };
  }
  if (proposal.name === 'save') {
    const body = proposal.args?.body;
    if (typeof body !== 'string' || body.length === 0 || body.length > 20000) {
      throw new Error('INVALID_REPORT');
    }
    const filename = path.join(directory, 'report.md');
    fs.writeFileSync(filename, body, { flag: 'wx' });
    saved = { filename, bytes: Buffer.byteLength(body, 'utf8') };
    return saved;
  }
  throw new Error('TOOL_NOT_ALLOWED');
}

function scriptedDecision(observations) {
  if (mode === 'early-finish') return { kind: 'finish', text: '写好了。' };
  if (mode === 'forbidden') return { kind: 'tool', name: 'read', args: { id: 'C' } };
  const reads = observations.filter(x => x.proposal.name === 'read');
  for (const id of ['A', 'B']) {
    if (!reads.some(x => x.result.id === id)) {
      return { kind: 'tool', name: 'read', args: { id } };
    }
  }
  if (!observations.some(x => x.proposal.name === 'save')) {
    const a = reads.find(x => x.result.id === 'A').result;
    const b = reads.find(x => x.result.id === 'B').result;
    let body = '# 两版指南比较\n\n以下为合成教学资料。\n\n';
    if (!a.ok || !b.ok) {
      body += `资料缺口：${[a, b].filter(x => !x.ok).map(x => x.id).join('、')}版未取得。\n`;
      for (const source of [a, b].filter(x => x.ok)) {
        body += `已确认${source.id}版格式：${source.document.formats.join('、')}。`;
        body += `来源：${source.id}.json，${source.document.version}。\n`;
      }
      body += '\n尚不能判断两版差异与共同条件。\n';
    } else {
      const added = b.document.formats.filter(x => !a.document.formats.includes(x));
      body += `B版比A版新增：${added.length ? added.join('、') : '没有新增格式'}。\n`;
      body += `每次导出上限：A版${a.document.maxRows}行，B版${b.document.maxRows}行。\n`;
      body += a.document.online && b.document.online
        ? '共同条件：两版导出均需联网。\n'
        : '不能概括为两版导出均需联网，请分别查看条件。\n';
      body += `\n来源：A.json（${a.document.version}）；B.json（${b.document.version}）。\n`;
    }
    return { kind: 'tool', name: 'save', args: { body } };
  }
  return { kind: 'finish', text: '报告已生成，请打开文件检查。' };
}

try {
  const maxRounds = 6;
  let finished = false;
  for (let round = 1; round <= maxRounds; round++) {
    const proposal = scriptedDecision(history);
    console.log(`第${round}轮：${proposal.kind === 'tool' ? proposal.name : 'finish'}`);
    if (proposal.kind === 'finish') {
      if (!saved || !fs.existsSync(saved.filename)) throw new Error('REPORT_REQUIRED');
      console.log(proposal.text);
      finished = true;
      break;
    }
    const result = dispatch(proposal);
    history.push({ proposal, result });
  }
  if (!finished) throw new Error('ROUND_LIMIT');
  console.log(JSON.stringify({ directory, report: saved, observations: history.length }, null, 2));
} catch (error) {
  console.error(JSON.stringify({ error: error.message, directory, saved }, null, 2));
  process.exitCode = 1;
}
