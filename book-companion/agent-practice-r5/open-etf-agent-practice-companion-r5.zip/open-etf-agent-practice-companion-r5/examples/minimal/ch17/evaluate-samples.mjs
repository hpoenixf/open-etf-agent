import assert from 'node:assert/strict';

// Synthetic review records. This script aggregates judgments, not model runs.
const samples = [
  { id: 'normal', ran: true, execution: true, evidence: true, content: true, delivery: true },
  { id: 'wrong-content', ran: true, execution: true, evidence: true, content: false, delivery: true },
  { id: 'missing-delivery', ran: true, execution: true, evidence: true, content: true, delivery: false },
  { id: 'not-run', ran: false, execution: null, evidence: null, content: null, delivery: null },
];
const axes = ['execution', 'evidence', 'content', 'delivery'];
const executed = samples.filter(sample => sample.ran);
const completed = executed.filter(sample => axes.every(axis => sample[axis] === true));
const notRun = samples.filter(sample => !sample.ran);
assert.equal(samples.length, 4);
assert.equal(executed.length, 3);
assert.equal(completed.length, 1);
assert.equal(notRun.length, 1);
assert.ok(notRun.every(sample => axes.every(axis => sample[axis] === null)));
console.log(JSON.stringify({
  kind: 'synthetic-review-records',
  planned: samples.length,
  executed: executed.length,
  completedAmongExecuted: `${completed.length}/${executed.length}`,
  executionCoverage: `${executed.length}/${samples.length}`,
  unknown: notRun.map(sample => sample.id),
  observations: samples,
}, null, 2));
