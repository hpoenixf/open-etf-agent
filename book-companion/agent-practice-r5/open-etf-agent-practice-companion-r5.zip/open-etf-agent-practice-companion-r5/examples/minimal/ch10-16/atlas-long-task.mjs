import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';

// Local, sequential teaching exercise. No model, network, database, or timer.
// It extends the Atlas Notes task, not a production durable execution system.
const sha = text => createHash('sha256').update(text).digest('hex');
const [action = 'ask', suppliedDirectory, choice = 'export-only'] = process.argv.slice(2);
const answers = {
  'export-only': '只核对导出，离线查看与编辑不在本次范围。',
  'view-and-edit': '我要判断离线查看与编辑，需要补充相应资料。'
};
let directory;
const writeState = state => {
  const temporary = path.join(directory, 'state.next.json');
  fs.writeFileSync(temporary, JSON.stringify(state, null, 2));
  fs.renameSync(temporary, path.join(directory, 'state.json'));
};
const loadState = () => {
  const state = JSON.parse(fs.readFileSync(path.join(directory, 'state.json'), 'utf8'));
  if (state.schema !== 'atlas-long-task@1') throw new Error('WRONG_EXERCISE');
  for (const id of ['A', 'B']) {
    const source = state.sources[id];
    const bytes = fs.readFileSync(path.join(directory, `${id}.json`), 'utf8');
    if (sha(bytes) !== source.sha256) throw new Error('SOURCE_CHANGED');
    source.document = JSON.parse(bytes);
  }
  return state;
};
try {
  if (action === 'ask') {
    directory = fs.mkdtempSync(path.join(process.cwd(), 'atlas-long-task-'));
    const sources = {};
    const documents = {
      A: { version: 'A-2026-01', formats: ['CSV'], maxRows: 120, online: true },
      B: { version: 'B-2026-02', formats: ['CSV', 'Markdown'], maxRows: 300, online: true }
    };
    for (const [id, document] of Object.entries(documents)) {
      const bytes = JSON.stringify(document);
      fs.writeFileSync(path.join(directory, `${id}.json`), bytes, { flag: 'wx' });
      const actual = fs.readFileSync(path.join(directory, `${id}.json`), 'utf8');
      sources[id] = { document: JSON.parse(actual), sha256: sha(actual) };
    }
    const taskId = randomUUID();
    const state = {
      schema: 'atlas-long-task@1', taskId,
      task: '比较A/B的导出能力，并澄清“能否离线使用”的范围。',
      allowedSources: ['A', 'B'], allowedTools: ['read', 'ask', 'save'],
      sources,
      pendingQuestion: {
        taskId, id: 'offline-scope-1',
        text: '你问的是离线查看与编辑，还是离线导出？现有摘录只说明导出条件。'
      },
      response: null, adopted: false, receipt: null,
      phase: 'awaiting-response', events: ['read:A', 'read:B', 'question:created']
    };
    writeState(state);
    console.log(JSON.stringify({ directory, taskId, question: state.pendingQuestion, phase: state.phase }, null, 2));
  } else {
    if (!suppliedDirectory) throw new Error('DIRECTORY_REQUIRED');
    directory = path.resolve(suppliedDirectory);
    const state = loadState();
    if (action === 'answer' || action === 'wrong-question') {
      const text = answers[choice];
      if (!text) throw new Error('UNKNOWN_ANSWER_CHOICE');
      const incoming = {
        taskId: state.taskId,
        questionId: action === 'wrong-question' ? 'another-question' : state.pendingQuestion.id,
        responseId: 'answer-1', text, sha256: sha(text)
      };
      if (incoming.taskId !== state.taskId || incoming.questionId !== state.pendingQuestion.id) {
        throw new Error('QUESTION_MISMATCH');
      }
      if (state.response) {
        if (state.response.responseId !== incoming.responseId || state.response.sha256 !== incoming.sha256) {
          throw new Error('RESPONSE_ID_CONFLICT');
        }
        console.log(JSON.stringify({ duplicate: true, response: state.response, phase: state.phase }, null, 2));
      } else {
        if (state.phase !== 'awaiting-response') throw new Error('QUESTION_CLOSED');
        state.response = incoming;
        state.events.push('response:received');
        writeState(state);
        console.log(JSON.stringify({ received: true, adopted: state.adopted, phase: state.phase }, null, 2));
      }
    } else if (action === 'resume') {
      if (!state.response) {
        console.log(JSON.stringify({ phase: state.phase, waiting: true, newQuestion: false }, null, 2));
      } else if (state.response.text !== answers['export-only']) {
        throw new Error('MORE_SOURCE_MATERIAL_REQUIRED');
      } else {
        if (!state.adopted) {
          state.adopted = true;
          state.phase = 'response-adopted';
          state.events.push('response:adopted');
          writeState(state);
        }
        const reportPath = path.join(directory, 'report.md');
        if (!state.receipt) {
          if (fs.existsSync(reportPath)) throw new Error('SAVE_OUTCOME_UNKNOWN');
          const a = state.sources.A.document, b = state.sources.B.document;
          const added = b.formats.filter(format => !a.formats.includes(format));
          const body = '# Atlas Notes两版导出比较\n\n合成教学资料。\n\n' +
            `B版新增格式：${added.join('、') || '无'}。\n` +
            `每次导出上限：A版${a.maxRows}行，B版${b.maxRows}行。\n` +
            (a.online && b.online ? '共同条件：两版导出均需联网。\n' : '联网条件需分别核对。\n') +
            '本次只判断导出，不对离线查看或编辑作结论。\n\n' +
            `已采用回答：${state.response.text}\n` +
            `来源：A.json（${a.version}）；B.json（${b.version}）。\n`;
          fs.writeFileSync(reportPath, body, { flag: 'wx' });
          state.receipt = { file: 'report.md', sha256: sha(body), bytes: Buffer.byteLength(body, 'utf8') };
          state.phase = 'report-saved';
          state.events.push('report:saved');
          writeState(state);
          if (choice === 'pause-after-save') {
            console.log(JSON.stringify({ paused: true, phase: state.phase, receipt: state.receipt }, null, 2));
            process.exit(0);
          }
        }
        const actual = fs.readFileSync(reportPath, 'utf8');
        if (sha(actual) !== state.receipt.sha256) throw new Error('REPORT_CHANGED');
        if (state.phase !== 'completed') {
          state.events.push('receipt:consumed');
          state.phase = 'completed';
          writeState(state);
        }
        console.log(JSON.stringify({ directory, taskId: state.taskId, phase: state.phase,
          receipt: state.receipt, events: state.events }, null, 2));
      }
    } else if (action === 'inspect') {
      console.log(JSON.stringify(state, null, 2));
    } else throw new Error('UNKNOWN_ACTION');
  }
} catch (error) {
  console.error(JSON.stringify({ error: error.message, directory }, null, 2));
  process.exitCode = 1;
}
