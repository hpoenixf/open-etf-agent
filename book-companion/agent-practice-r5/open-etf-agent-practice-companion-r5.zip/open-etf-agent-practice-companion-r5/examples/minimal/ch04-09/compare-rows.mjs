import assert from 'node:assert/strict';

// Synthetic rows from the book. This is a small function exercise, not a store.
const rows = [
  { id: 'dividend-current', category: 'dividend', role: 'current', value: 40000, unit: 'CNY', asOf: '2026-10-01' },
  { id: 'dividend-target', category: 'dividend', role: 'target', value: 30000, unit: 'CNY', asOf: '2026-10-01' },
  { id: 'overseas-current', category: 'overseas', role: 'current', value: 20000, unit: 'CNY', asOf: '2026-10-01' },
  { id: 'overseas-target', category: 'overseas', role: 'target', value: 25000, unit: 'CNY', asOf: '2026-10-01' },
];
export function difference(baseline, target) {
  if (![baseline.value, target.value].every(Number.isFinite)) throw new Error('NUMBER_REQUIRED');
  if (baseline.unit !== target.unit || baseline.asOf !== target.asOf) throw new Error('BASIS_MISMATCH');
  return { difference: target.value - baseline.value, rowIds: [baseline.id, target.id], unit: baseline.unit };
}
export function sameCategoryChange(baseline, target) {
  if (baseline.category !== target.category || baseline.role !== 'current' || target.role !== 'target') {
    throw new Error('PAIR_MISMATCH');
  }
  return difference(baseline, target);
}
const right = sameCategoryChange(rows[0], rows[1]);
const wrongQuestion = difference(rows[0], rows[3]);
assert.equal(right.difference, -10000);
assert.equal(wrongQuestion.difference, -15000);
assert.throws(() => sameCategoryChange(rows[0], rows[3]), /PAIR_MISMATCH/);
assert.throws(() => difference(rows[0], { ...rows[1], unit: 'USD' }), /BASIS_MISMATCH/);
console.log(JSON.stringify({ right, wrongQuestion, guardedWrongPair: 'PAIR_MISMATCH', mixedUnits: 'BASIS_MISMATCH' }, null, 2));
