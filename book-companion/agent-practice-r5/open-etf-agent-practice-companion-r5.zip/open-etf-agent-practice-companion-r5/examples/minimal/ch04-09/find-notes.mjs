import assert from 'node:assert/strict';

// Short synthetic notes adapted from examples/ch06/research-notes.json.
const documents = [
  { id: 'portfolio-policy', version: '1', text: '现金当前5000 CNY，固定目标10000 CNY。合成快照日期2026-10-01。' },
  { id: 'portfolio-revision', version: '1', text: '现金须与非现金增减一同核对。合成算例不含费用、税费、滑点和最小交易单位。' },
  { id: 'meeting-draft', version: '1', text: '现金 现金 现金。另一项合成练习的目标12000，不属于本次范围。' },
];
const allowed = new Set(['portfolio-policy', 'portfolio-revision']);
function search(query) {
  if (typeof query !== 'string' || !query.trim()) throw new Error('QUERY_REQUIRED');
  return documents.filter(d => allowed.has(d.id) && d.text.includes(query))
    .map(d => ({ id: d.id, version: d.version, acquired: false }));
}
function read(id) {
  if (!allowed.has(id)) throw new Error('SOURCE_NOT_ALLOWED');
  const document = documents.find(d => d.id === id);
  if (!document) throw new Error('SOURCE_MISSING');
  return { ...document, acquired: true };
}
const candidates = search('现金');
const acquired = candidates.map(c => read(c.id));
assert.equal(candidates.length, 2);
assert(candidates.every(c => c.acquired === false));
assert(acquired.every(c => c.acquired === true));
assert.equal(search('备用金').length, 0);
assert.throws(() => read('meeting-draft'), /SOURCE_NOT_ALLOWED/);
console.log(JSON.stringify({ candidates, acquired, alternateQuery: search('备用金'), rejected: 'meeting-draft' }, null, 2));
