import assert from 'node:assert/strict';

// A boundary exercise for first-loop.mjs; no model, network, or file access.
function validateRead(proposal) {
  if (proposal?.kind !== 'tool' || proposal?.name !== 'read') {
    return { ok: false, code: 'TOOL_NOT_ALLOWED', dispatched: false };
  }
  if (typeof proposal.args?.id !== 'string') {
    return { ok: false, code: 'ID_REQUIRED', dispatched: false };
  }
  if (!['A', 'B'].includes(proposal.args.id)) {
    return { ok: false, code: 'SOURCE_NOT_ALLOWED', dispatched: false };
  }
  return { ok: true, proposal };
}
const proposals = [
  { kind: 'tool', name: 'read', args: {} },
  { kind: 'tool', name: 'read', args: { id: 'B' } },
];
const history = [];
for (let i = 0; i < proposals.length; i++) {
  // The second candidate represents an explicit repair of the missing parameter.
  const checked = validateRead(proposals[i]);
  history.push({ proposal: proposals[i], validation: checked.ok ? { ok: true } : checked });
}
assert.equal(history[0].validation.code, 'ID_REQUIRED');
assert.equal(history[0].validation.dispatched, false);
assert.equal(history[1].validation.ok, true);
assert.equal(validateRead({ kind: 'tool', name: 'read', args: { id: 'C' } }).code, 'SOURCE_NOT_ALLOWED');
console.log(JSON.stringify({ history, note: '参数已修正；本练习没有执行读取。' }, null, 2));
