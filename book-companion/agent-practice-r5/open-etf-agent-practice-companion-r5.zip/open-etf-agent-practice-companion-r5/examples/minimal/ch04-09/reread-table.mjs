import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

// Run in a new process against your own directory created by create-table.mjs.
const directory = process.argv[2];
if (!directory) throw new Error('DIRECTORY_REQUIRED');
const receipt = JSON.parse(fs.readFileSync(path.join(directory, 'receipt.json'), 'utf8'));
assert.equal(receipt.filename, 'comparison.csv');
const bytes = fs.readFileSync(path.join(directory, 'comparison.csv'));
const digest = createHash('sha256').update(bytes).digest('hex');
assert.equal(bytes.length, receipt.bytes);
assert.equal(digest, receipt.sha256);
// A same-length alternative is kept in memory. The saved file is not changed.
const changed = Buffer.from(bytes.toString('utf8').replace('CSV', 'TSV'), 'utf8');
assert.equal(changed.length, bytes.length);
assert.notEqual(createHash('sha256').update(changed).digest('hex'), receipt.sha256);
console.log(JSON.stringify({ reopened: true, bytes: bytes.length, sameContent: true, sameLengthIsNotEnough: true }, null, 2));
