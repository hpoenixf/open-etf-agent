import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

// Three synthetic rows. This demonstrates CSV escaping, not formula protection.
const rows = [
  ['版本', '格式与说明'],
  ['A', 'CSV,需联网'],
  ['B', '新增"Markdown"\n仍需联网'],
];
function cell(text) {
  if (typeof text !== 'string') throw new Error('TEXT_REQUIRED');
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}
function encode(table) {
  if (!table.length || !table[0].length) throw new Error('ROWS_REQUIRED');
  const width = table[0].length;
  if (table.some(row => !Array.isArray(row) || row.length !== width)) throw new Error('WIDTH_MISMATCH');
  return table.map(row => row.map(cell).join(',')).join('\r\n') + '\r\n';
}
const naive = rows.map(row => row.join(',')).join('\n');
const csv = encode(rows);
assert.equal(cell('CSV,需联网'), '"CSV,需联网"');
assert.equal(cell('新增"Markdown"\n仍需联网'), '"新增""Markdown""\n仍需联网"');
assert.throws(() => encode([['a', 'b'], ['a']]), /WIDTH_MISMATCH/);
assert.throws(() => encode([['a'], [1]]), /TEXT_REQUIRED/);
assert.notEqual(naive, csv);
const directory = fs.mkdtempSync(path.join(process.cwd(), 'tiny-table-'));
const bytes = Buffer.from(csv, 'utf8');
const receipt = { filename: 'comparison.csv', bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
fs.writeFileSync(path.join(directory, receipt.filename), bytes, { flag: 'wx' });
fs.writeFileSync(path.join(directory, 'receipt.json'), JSON.stringify(receipt, null, 2), { flag: 'wx' });
console.log('朴素拼接：\n' + naive);
console.log('正确转义：\n' + csv);
console.log(JSON.stringify({ directory, receipt }, null, 2));
