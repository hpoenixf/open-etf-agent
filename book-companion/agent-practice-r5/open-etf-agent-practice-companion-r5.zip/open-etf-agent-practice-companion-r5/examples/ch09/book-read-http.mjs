import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';

const origin = new URL(process.env.ORIGIN);
assert.equal(origin.protocol, 'http:');
assert.equal(origin.hostname, '127.0.0.1');
assert.equal(origin.pathname, '/');
assert.equal(origin.search, '');
assert.equal(origin.hash, '');
assert.equal(origin.username, '');
assert.equal(origin.password, '');
const result = JSON.parse(
  await readFile('book-output/ch03-result.json', 'utf8')
);
const receipt = result.receipt;
const response = await fetch(new URL(
  '/artifacts/' + receipt.artifactId, origin
));
assert.equal(response.status, 200);
assert.equal(response.headers.get('content-type'), receipt.mediaType);
const bytes = Buffer.from(await response.arrayBuffer());
const digest = createHash('sha256').update(bytes).digest('hex');
assert.equal(bytes.length, receipt.bytes);
assert.equal(digest, receipt.sha256);
assert.deepEqual(bytes, await readFile(join(result.directory, 'report.md')));

const revisionResponse = await fetch(new URL(
  '/revisions/' + receipt.revisionId, origin
));
assert.equal(revisionResponse.status, 200);
const revision = await revisionResponse.json();
assert.equal(revision.revisionId, receipt.revisionId);
assert.equal(revision.reportId, receipt.artifactId);
assert.deepEqual(revision.attachmentIds, receipt.attachmentIds);
console.log('HTTP报告字节、修订与原保存回执相符。');
