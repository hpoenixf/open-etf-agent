import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { assertFixedRepository } from '../check-base.mjs';
const args = process.argv.slice(2);
assert(args.length % 2 === 0);
const options = Object.fromEntries(Array.from({ length: args.length / 2 }, (_, index) => [args[index * 2], args[index * 2 + 1]]));
assert(Object.keys(options).every(key => ['--repo', '--output', '--project', '--phase'].includes(key)));
const repo = assertFixedRepository(resolve(options['--repo'] ?? '.'));
const module = await import(pathToFileURL(join(repo, 'src/research-project.mjs')));
const { importProjectSources } = await import(pathToFileURL(join(repo, 'src/project-sources.mjs')));
const { createResearchProject, submitResearchTask, workResearchTask, inspectResearchTask, respondResearchTask, listResearchInteractions, readResearchReport } = module;
const runId = 'cash-basis-1';
const answer = '只核对给定金额之间的现金关系，费用后的可用资金不在本次范围。';
const question = '请根据现有合成组合说明，补一页现金核对，解释可用现金怎样由当前值变成固定目标。若可用现金的口径不明确，先问我。保留原快照的金额与日期，不提出交易建议。';
const config = {
  schemaVersion: 'research-project@1',
  gateway: { mode: 'fixture', provider: 'local', protocol: 'fixture@1', model: 'book-cash-clarification' },
  capabilities: ['report', 'response'],
  allowedTools: ['read_page', 'read_result', 'ask_response', 'save_report'],
  interaction: { schemaVersion: 'human-interaction@1', maxQuestions: 2 },
  limits: { maxRounds: 8, maxTools: 8, timeoutMs: 3600000, model: 8, tool: 8 }
};
if (!options['--phase']) {
  assert(options['--output'], 'Supply --output OUTPUT_ROOT');
  await mkdir(resolve(options['--output']), { recursive: true });
  const project = await mkdtemp(join(resolve(options['--output']), 'book-cash-project-'));
  const phases = [];
  for (const phase of ['prepare', 'ask', 'respond', 'pause', 'resume']) {
    const stdout = execFileSync(process.execPath, [fileURLToPath(import.meta.url), '--repo', repo, '--project', project, '--phase', phase], { encoding: 'utf8', maxBuffer: 2097152 });
    phases.push(JSON.parse(stdout));
  }
  assert.equal(phases.reduce((sum, phase) => sum + phase.gatewayCalls, 0), 4);
  console.log(JSON.stringify({ check: 'cross-process-cash-clarification-and-committed-save-resume', mode: 'fixture', providerCalls: 0, cooperativeStopsOnly: true, abruptProcessKillTested: false, project, runId, phases, semanticStatus: 'unreviewed' }, null, 2));
} else {
  const projectDir = resolve(options['--project']);
  const phase = options['--phase'];
  let gatewayCalls = 0;
  const controlFile = join(projectDir, 'book-exercise-control.json');
  if (phase === 'prepare') {
    await createResearchProject({ directory: projectDir, config });
    const imported = await importProjectSources({ projectDir, files: [fileURLToPath(new URL('./cash-basis.md', import.meta.url))] });
    await submitResearchTask({ projectDir, runId, question, sourceManifestSha256: imported.manifestSha256 });
    const current = await inspectResearchTask({ projectDir, runId });
    await writeFile(controlFile, JSON.stringify({ documentId: imported.catalog.documents[0].id, grantId: current.definition.grantId, sourceManifestSha256: current.definition.sourceManifestSha256, deadlineAt: current.run.definition.deadlineAt }) + '\n', { flag: 'wx' });
    assert.equal(current.run.rootUsage.model, 0);assert.equal(current.run.rootUsage.tool, 0);
    console.log(JSON.stringify({ phase, gatewayCalls, status: current.run.status }));
  } else {
    const control = JSON.parse(await readFile(controlFile, 'utf8'));
    const gateway = { mode: 'fixture', async next({ messages }) {
      gatewayCalls++;
      const tools = messages.filter(message => message.role === 'tool');
      assert(tools.every(message => message.result.status === 'succeeded'));
      const source = tools.map(message => message.result.value).find(value => value?.documentId === control.documentId && value?.sourceId);
      const reply = tools.find(message => message.callId === 'ask-cash-basis')?.result.value;
      const saved = tools.find(message => message.callId === 'save-cash-note')?.result.value;
      const call = (id, name, arguments_) => ({ kind: 'calls', calls: [{ id, name, arguments: arguments_ }] });
      if (!source) return call('read-cash-basis', 'read_page', { documentId: control.documentId, page: 1 });
      if (!reply) return call('ask-cash-basis', 'ask_response', { question: '这页说明只核对给定金额之间的现金关系，还是需要核对扣除费用后的可用资金？现有合成材料没有费用数据，后一种口径需要补充资料。' });
      assert.equal(reply.kind, 'human-interaction@1');assert.equal(reply.text, answer);
      if (!saved) return call('save-cash-note', 'save_report', {
        text: '# 合成组合现金口径补充\n\n数据时点2026-10-01；币种CNY。当前现金5000，固定目标10000。非现金类别减少15000、增加10000，因此5000 + 15000 - 10000 = 10000。[1]\n\n本次只核对给定金额之间的现金关系，不计算费用后的可用资金。材料未提供费用，不表示真实费用为零。固定目标由教学输入预设，没有投资建议或交易。\n\n本页依据明确标记的合成转录说明，不替代之前的原始行绑定计算。',
        sourceIds: [source.sourceId]
      });
      return { kind: 'final', text: '已保存合成现金口径补充说明；费用后的可用资金不在本次范围。' };
    } };
    let result;
    if (phase === 'ask') {
      result = await workResearchTask({ projectDir, runId, gateway });
      assert.equal(result.workerStatus, 'awaiting-response');assert.equal(result.run.status, 'active');
      const used = structuredClone(result.run.rootUsage);const callsBefore = gatewayCalls;
      const again = await workResearchTask({ projectDir, runId, gateway });
      assert.equal(again.workerStatus, 'awaiting-response');assert.deepEqual(again.run.rootUsage, used);assert.equal(gatewayCalls, callsBefore);
      console.log(JSON.stringify({ phase, gatewayCalls, workerStatus: result.workerStatus, rootUsage: used, noAnswerRedrive: 'no-new-calls' }));
    } else if (phase === 'respond') {
      const pending = (await listResearchInteractions({ projectDir, runId })).items.find(item => item.state === 'awaiting-response');
      assert(pending);
      const input = { projectDir, runId, questionId: pending.questionId, responseId: 'cash-basis-answer-1', text: answer };
      const receipt = await respondResearchTask(input);
      assert.deepEqual(await respondResearchTask(input), receipt);
      await assert.rejects(respondResearchTask({ ...input, text: answer + '另一个文本。' }), error => error.code === 'RESPONSE_ID_CONFLICT');
      assert.equal((await listResearchInteractions({ projectDir, runId })).items[0].state, 'received-not-adopted');
      console.log(JSON.stringify({ phase, gatewayCalls, state: 'received-not-adopted', exactRetry: 'same-receipt', changedText: 'RESPONSE_ID_CONFLICT' }));
    } else if (phase === 'pause') {
      const host = new AbortController();
      result = await workResearchTask({ projectDir, runId, gateway, hostSignal: host.signal, onCheckpoint(event) {
        if (event.phase === 'result-committed' && event.callId === 'save-cash-note') host.abort();
      } });
      assert.equal(result.workerStatus, 'interrupted');assert.equal(result.run.status, 'active');assert.equal(result.run.snapshot.phase, 'result-committed');
      const receipt = result.run.snapshot.host.receipt;assert(receipt);
      await writeFile(join(projectDir, 'book-paused-receipt.json'), JSON.stringify(receipt) + '\n', { flag: 'wx' });
      console.log(JSON.stringify({ phase, gatewayCalls, workerStatus: result.workerStatus, checkpoint: result.run.snapshot.phase, revisionId: receipt.revisionId, rootUsage: result.run.rootUsage }));
    } else if (phase === 'resume') {
      result = await workResearchTask({ projectDir, runId, gateway });
      assert.equal(result.run.status, 'completed', result.run.snapshot.code);
      const report = await readResearchReport({ projectDir, runId });
      const paused = JSON.parse(await readFile(join(projectDir, 'book-paused-receipt.json'), 'utf8'));
      assert.equal(report.receipt.revisionId, paused.revisionId);assert.equal(report.report.sha256, paused.sha256);
      assert.equal(result.run.snapshot.messages.filter(message => message.role === 'tool' && message.callId === 'save-cash-note').length, 1);
      assert.equal((await listResearchInteractions({ projectDir, runId })).items[0].state, 'adopted');
      const inspected = await inspectResearchTask({ projectDir, runId });
      assert.equal(inspected.definition.grantId, control.grantId);assert.equal(inspected.definition.sourceManifestSha256, control.sourceManifestSha256);assert.equal(inspected.run.definition.deadlineAt, control.deadlineAt);
      assert.match(report.report.text, /不计算费用后的可用资金/);assert.equal(result.run.rootUsage.model, 4);assert.equal(result.run.rootUsage.tool, 3);
      const before = gatewayCalls;await workResearchTask({ projectDir, runId, gateway });assert.equal(gatewayCalls, before);
      console.log(JSON.stringify({ phase, gatewayCalls, status: result.run.status, sameRevision: true, oneConsumedSave: true, originalIdentityAndDeadlineRetained: true, terminalRedrive: 'no-new-calls', rootUsage: result.run.rootUsage }));
    } else throw new Error('Unknown exercise phase');
  }
}
