import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { realpathSync } from 'node:fs';

export const BOOK_BASE_SHA = 'b22c43633101a10a50fc5b09ecc5ecba038f873a';
export function assertFixedRepository(directory) {
  const root = realpathSync(directory);
  const git = (...args) => execFileSync('git', ['-C', root, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
  assert.equal(realpathSync(git('rev-parse', '--show-toplevel')), root, 'Use the repository root.');
  assert.equal(git('rev-parse', 'HEAD'), BOOK_BASE_SHA, 'Use the fixed v0.21.0 book source.');
  git('diff', '--quiet', 'HEAD', '--', 'src', 'fixtures', 'package.json', 'package-lock.json');
  return root;
}
