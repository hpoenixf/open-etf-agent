# 附录 D 准备真实项目的练习环境

本附录只服务正文中的真实项目案例。第三章的单文件入门实验不依赖这里的安装步骤；你可以先读通用主线，需要查看工程实现时再准备。

## 先取得独立配套包

随本书审读稿提供的文件是open-etf-agent-practice-companion-r5.zip。获取渠道与完整性校验见书前《配套资源与复现说明》。公开v0.21.0的源码树没有examples目录；本包与项目源码必须分别取得。

先在解压后的配套根目录运行校验，随后记录这个目录：

```bash
node verify-files.mjs
BOOK_SOURCE="$PWD"
export BOOK_SOURCE
```

此处PWD是当前终端目录。应能在其中找到examples/check-base.mjs。新终端需要重新进入配套根目录执行上述赋值，或手工设置其真实绝对路径；不要把中文占位文字当成实际路径。

## 使用固定公开版本

本书的工程案例固定为Open ETF Agent v0.21.0，提交：

```text
b22c43633101a10a50fc5b09ecc5ecba038f873a
```

该版本要求Node.js不低于26.8.1且低于27，作者的项目例程使用26.11.1。它与单文件入门实验的24.19.0验证环境分开。先检查终端实际选中的版本，不要在同一份实验记录中混用两个环境。

下面的命令使用Bash语法。在另一个新建的工作目录取得源码，不切换正在开发的项目；保留刚才终端中已导出的BOOK_SOURCE：

```bash
git clone --depth 1 --branch v0.21.0 \
  https://github.com/hpoenixf/open-etf-agent.git \
  open-etf-agent-book
cd open-etf-agent-book
node --version
git rev-parse HEAD
```

最后一项应返回上面的完整提交。固定标签进入分离头指针状态是正常现象，我们在读取一个确定快照。配套包保存在前面已校验的目录，不覆盖公开源码。

安装锁定依赖并构建：

```bash
npm ci --ignore-scripts --no-audit --no-fund
npm run build
```

首次安装可能访问npm，离线例程不调用模型。`--ignore-scripts`避免运行依赖安装脚本，不代表已经完成依赖安全审核。若默认缓存目录不可写，可在当前工作区指定`--cache .book-npm-cache`，不用改变系统目录权限。保留锁文件，不为绕过安装问题随意升级依赖。

构建检查并复制原生ESM文件和示例资料。正文为了便于阅读实现，采用`src/`入口。确认BOOK_SOURCE仍指向刚才校验的配套根目录，再运行固定源码检查：

```bash
test -n "$BOOK_SOURCE" || { echo "请先设置配套目录"; exit 1; }
mkdir -p book-output
node --input-type=module -e '
  import { pathToFileURL } from "node:url";
  const entry = pathToFileURL(process.argv[1]);
  const check = await import(entry);
  console.log(check.assertFixedRepository("."));
' "$BOOK_SOURCE/examples/check-base.mjs"
```

BOOK_SOURCE指向配套包，当前目录指向公开源码，二者不要交换。这个检查核对Git根、固定提交和相关源码，不替代依赖、平台或安全认证。若你使用其他终端，应确认对应变量与引号写法；本书不把Bash记录当作全平台执行证明。

## 先运行项目自带的文档比较

在公开源码目录中执行：

```bash
node src/cli.mjs --case T1 --output book-output/t1 \
  > book-output/t1-result.json
```

这条命令只执行T1文档比较。输出仍保留T1—T4的固定计划清单，另外三题标为`not-run`。本次目录在`cases`数组中对应T1的记录里，不在整个JSON的顶层。

使用实际记录打开报告：

```bash
node --input-type=module -e '
  import fs from "node:fs";
  import path from "node:path";
  const result = JSON.parse(fs.readFileSync(
    "book-output/t1-result.json", "utf8"
  ));
  const item = result.cases.find(x => x.caseId === "T1");
  console.log(fs.readFileSync(
    path.join(item.directory, "report.md"), "utf8"
  ));
'
```

报告比较免费导出格式，保留共同联网条件，并说明PDF是企业版能力。它还保存本次实际取得的两个页面来源。默认决策来自脚本替身，工程状态完成而`semanticStatus`仍为`unreviewed`；不能把该字段当成模型质量已评审。

## 准备后续数值案例的共同起点

组合案例与T1是两次独立运行。执行：

```bash
node src/cli.mjs --case portfolio-rebalance \
  --output book-output/runs \
  > book-output/ch03-result.json
```

配套回查工具约定使用`ch03-result.json`这个文件名。它属于程序之间的输入约定，不表示组合案例必须在第三章之前完成。先取得这份结果，随后第4、8、9、17章的工程检查才能沿同一份记录回查。

这个专用案例的返回形状不同，运行目录位于顶层`directory`。不要把T1清单的读取逻辑机械套到它身上，也不要将组合任务改名为T1来借用四题评测器。

```bash
RUN_DIR=$(node --input-type=module -e '
  import fs from "node:fs";
  const result = JSON.parse(fs.readFileSync(
    "book-output/ch03-result.json", "utf8"
  ));
  console.log(result.directory);
')
node \
  "$BOOK_SOURCE/examples/ch03/inspect-first-report.mjs" \
  book-output/ch03-result.json
```

正文第4、8、9、17章会沿这份实际结果追踪来源、表格和回读。保留目录，再为其他练习使用新位置，不覆盖旧结果。所有后续示例都应从本次输出取得实际身份，不能照抄作者的随机运行目录。

## 为什么有的章节使用程序API

固定版演示CLI拒绝`--live`。研究项目CLI可以在fixture配置下初始化、导入和提交，但`run work`拒绝fixture执行。需要离线执行研究项目的配套脚本，通过公开API注入与配置一致的网关。它们不是删掉拒绝检查之后的隐藏CLI用法。

项目导入支持明确选择的文本、Markdown和PDF文件。第10章现金说明是教学转录，不因数值相同就继承原组合JSON的行绑定。普通响应、子任务和计划执行也有明确的组合范围，分别建立项目是在遵守这些范围。

这些条件只属于本书固定实现，不是所有Agent都必须采用的结构。正文先解释通用问题，案例层再说明这份代码选择了哪一种做法。

## 出错时先核对最小条件

先检查当前目录和Node版本，再看命令需要的是项目源码目录还是随书文件目录。文件找不到时，从实际JSON取得路径；参数拒绝时，对照该入口支持范围。不要一次同时换Node、升级依赖、改输入和删旧状态。

工程例程的逐项离线记录与轻量练习分别保留。轻量路径已在Linux、Node.js 24.19.0的新空目录按正文顺序执行；工程路径的记录使用固定源码与既有Node.js 26.11.1环境。真实模型、其他操作系统及全新安装环境仍需分别验证。
