import { strict as assert } from 'node:assert';
import * as fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeLive, makeReplay, run, readBack } from './model-loop.mjs';
const here = path.dirname(fileURLToPath(import.meta.url));
const root = fs.mkdtempSync(path.join(process.cwd(), 'atlas-protocol-test-'));
const fixture = JSON.parse(fs.readFileSync(path.join(here, 'replay.json'), 'utf8'));
const task = fs.readFileSync(path.join(here, 'task-card.md'), 'utf8');
const execute = adapter => run({ adapter, sourceDir: path.join(here, 'sources'), task, outputRoot: root });
const results = [];
const original = await execute(makeReplay(fixture));
assert.equal(original.summary.outcome, 'COMPLETED');
assert.match(readBack(original.out).report, /联网/);
assert.equal(original.summary.acquired.length, 3);
assert.equal(original.summary.requests, 5);
results.push('normal-five-rounds-source-receipts-and-readback');
let mockedRequests = 0;
const fakeTransport = async (url, options) => {
  assert.equal(url, 'https://api.openai.com/v1/responses');
  assert.equal(options.headers.Authorization, 'Bearer test-placeholder-not-a-credential');
  const body = JSON.parse(options.body);
  assert.equal(body.store, false); assert.equal(body.parallel_tool_calls, false);
  assert.equal(body.input.filter(i => i.type === 'function_call_output').length, mockedRequests);
  if (mockedRequests === 3) assert.match(body.input.at(-1).output, /联网/);
  return { ok: true, json: async () => structuredClone(fixture.steps[mockedRequests++].response) };
};
const transportResult = await execute(makeLive('test-model', 'test-placeholder-not-a-credential', fakeTransport));
assert.equal(transportResult.summary.outcome, 'COMPLETED');
assert.equal(mockedRequests, 5);
assert.equal(transportResult.summary.mode, 'mock-api');
assert.equal(transportResult.summary.externalModelCalls, 0);
results.push('live-adapter-request-shape-with-local-mock-no-network');
const mutations = {
  incomplete: f => { f.steps[0].response.status = 'incomplete'; },
  duplicateCall: f => { f.steps[1].response.output[0].call_id = 'call_1'; },
  multipleCalls: f => { f.steps[0].response.output.push(structuredClone(f.steps[0].response.output[0])); },
  unknownSource: f => { f.steps[0].response.output[0].arguments = '{"id":"C"}'; },
  missingResult: f => { f.steps[1].resultsBefore = 0; },
  earlyFinish: f => { f.steps[0].response.output = []; },
  unsourcedReport: f => { f.steps[0].response.output[0] = { type: 'function_call', call_id: 'bad', name: 'save_report', arguments: '{"body":"Made up","sourceIds":["A"]}' }; }
};
for (const [name, mutate] of Object.entries(mutations)) {
  const f = structuredClone(fixture); mutate(f);
  const result = await execute(makeReplay(f));
  assert.notEqual(result.summary.outcome, 'COMPLETED', name);
  assert.equal(result.summary.saved, null, name);
  results.push(name);
}
fs.appendFileSync(path.join(original.out, 'report.md'), 'changed');
assert.throws(() => readBack(original.out), /REPORT_BYTES_CHANGED/);
results.push('changed-file-detected');
console.log(JSON.stringify({ node: process.version, checks: results, actualNetworkRequests: 0, directory: root,
  note: 'The live adapter was checked with an injected local transport, not against the provider.' }, null, 2));
