// R6.1 reader exercises. Local, synthetic and offline; originals stay unchanged.
import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const here = path.dirname(fileURLToPath(import.meta.url));
const root = fs.mkdtempSync(path.join(process.cwd(), 'reader-corrections-'));
const checks = [];
function invoke(file, args = [], expected = 0) {
  const p = spawnSync(process.execPath, [file, ...args], { cwd: root, encoding: 'utf8', timeout: 15000 });
  assert.equal(p.status, expected, p.stderr || p.stdout || String(p.error));
  return p;
}
const json = p => JSON.parse(p.stdout);
function check(name, action) { action(); checks.push({ case: name, passed: true }); }
function changedCopy(source, destination, before, after) {
  const text = fs.readFileSync(source, 'utf8');
  assert(text.includes(before), `Mutation target missing: ${before}`);
  fs.writeFileSync(destination, text.replace(before, after));
  return destination;
}
check('chapter6-authorized-B-guide-yields-one-candidate-and-document', () => {
  const source = path.join(here, 'ch04-09/find-notes.mjs');
  const file = changedCopy(source, path.join(root, 'find-one.mjs'),
    "new Set(['B-guide', 'B-appendix'])", "new Set(['B-guide'])");
  changedCopy(file, file, 'assert.equal(candidates.length, 2)', 'assert.equal(candidates.length, 1)');
  const result = json(invoke(file));
  assert.deepEqual(result.candidates.map(d => d.id), ['B-guide']);
  assert.deepEqual(result.acquired.map(d => [d.id, d.acquired]), [['B-guide', true]]);
});
const samples = path.join(here, 'ch17/evaluate-samples.mjs');
check('chapter17-unsupported-written-claim-fails-content-and-evidence', () => {
  const result = json(invoke(samples));
  const wrong = result.observations.find(s => s.id === 'wrong-content');
  assert.equal(wrong.content, false); assert.equal(wrong.evidence, false);
  assert.equal(result.completedAmongExecuted, '1/3');
});
check('chapter17-correcting-only-content-keeps-unsupported-evidence', () => {
  const file = changedCopy(samples, path.join(root, 'content-only.mjs'),
    "id: 'wrong-content', ran: true, execution: true, evidence: false, content: false",
    "id: 'wrong-content', ran: true, execution: true, evidence: false, content: true");
  assert.equal(json(invoke(file)).completedAmongExecuted, '1/3');
});
check('chapter17-correcting-both-judgments-and-expectation-yields-two-of-three', () => {
  const file = changedCopy(samples, path.join(root, 'both-corrected.mjs'),
    "id: 'wrong-content', ran: true, execution: true, evidence: false, content: false",
    "id: 'wrong-content', ran: true, execution: true, evidence: true, content: true");
  changedCopy(file, file, 'assert.equal(completed.length, 1)', 'assert.equal(completed.length, 2)');
  const result = json(invoke(file));
  assert.equal(result.completedAmongExecuted, '2/3');
  assert.equal(result.executionCoverage, '3/4'); assert.deepEqual(result.unknown, ['not-run']);
});
check('chapter17-text-review-distinguishes-omission-from-unsupported-claim', () => {
  const result = json(invoke(samples, ['--reviews', path.join(here, 'ch17/reports/example-reviews.json')]));
  assert.equal(result.contentAndEvidencePassed, 1);
  assert.deepEqual(result.observations.map(r => [r.content, r.evidence]), [[true,true],[false,true],[false,false]]);
  assert(!result.observations[2].reason.includes('180'));
});
const capstone = path.join(here, 'capstone');
const reader = path.join(here, 'ch05/model-loop.mjs');
let oldDirectory;
check('existing-report-readback-detects-post-save-byte-change', () => {
  const result = json(invoke(path.join(capstone, 'run.mjs'), ['normal']));
  oldDirectory = result.directory;
  invoke(reader, ['readback', oldDirectory]);
  const report = path.join(oldDirectory, 'report.md');
  changedCopy(report, report, '180', '300');
  const rejected = invoke(reader, ['readback', oldDirectory], 1);
  assert.match(rejected.stderr + rejected.stdout, /REPORT_BYTES_CHANGED/);
});
check('verify-reruns-three-scenarios-and-does-not-validate-the-old-directory', () => {
  const result = json(invoke(path.join(capstone, 'verify.mjs')));
  assert.equal(result.mode, 'regenerate-and-verify-new-results');
  assert.equal(result.reusesPreviousOutputs, false);
  assert.notEqual(result.directory, oldDirectory);
  assert.equal(result.accepted.length, 3);
  assert(result.accepted.every(s => s.externalModelCalls === 0));
  assert.match(invoke(reader, ['readback', oldDirectory], 1).stderr, /REPORT_BYTES_CHANGED/);
});
check('pre-save-wrong-content-passes-byte-readback-but-fails-fixed-reference', () => {
  const copy = path.join(root, 'mutated-source');
  for (const dir of ['ch05','capstone']) fs.cpSync(path.join(here, dir), path.join(copy, dir), { recursive: true });
  const fixture = path.join(copy, 'capstone/normal.json');
  const replay = JSON.parse(fs.readFileSync(fixture, 'utf8'));
  const call = replay.steps.flatMap(s => s.response.output).find(o => o.name === 'save_report');
  const args = JSON.parse(call.arguments);
  const field = Object.keys(args).find(k => typeof args[k] === 'string' && args[k].includes('180'));
  assert(field, 'Expected report body in save_report arguments');
  args[field] = args[field].replace('180', '300'); call.arguments = JSON.stringify(args);
  fs.writeFileSync(fixture, JSON.stringify(replay, null, 2) + '\n');
  const wrong = json(invoke(path.join(copy, 'capstone/run.mjs'), ['normal']));
  invoke(path.join(copy, 'ch05/model-loop.mjs'), ['readback', wrong.directory]);
  const failed = invoke(path.join(copy, 'capstone/verify.mjs'), [], 1);
  assert.match(failed.stderr, /AssertionError/);
  assert.match(failed.stderr, /REPORT_CONTENT_MISMATCH/);
});
console.log(JSON.stringify({ node: process.version, cases: checks, passed: checks.length,
  externalModelCalls: 0, directory: root,
  scope: 'Local fixed exercise expectations and byte-integrity checks, not an automatic semantic grader or live-model test.' }, null, 2));
