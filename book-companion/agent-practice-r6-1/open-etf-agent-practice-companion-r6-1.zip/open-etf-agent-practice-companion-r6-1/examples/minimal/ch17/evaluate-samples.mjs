import assert from 'node:assert/strict';
import * as fs from 'node:fs';

if (process.argv[2] === '--reviews') {
  if (process.argv.length !== 4) throw new Error('USAGE_REVIEWS_FILE');
  const reviews = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
  assert(Array.isArray(reviews) && reviews.length > 0);
  assert.equal(new Set(reviews.map(r => r.id)).size, reviews.length);
  for (const r of reviews) {
    assert(typeof r.id === 'string' && typeof r.reason === 'string' && r.reason.trim());
    assert([true, false, null].includes(r.content));
    assert([true, false, null].includes(r.evidence));
  }
  const judged = reviews.filter(r => r.content !== null && r.evidence !== null);
  console.log(JSON.stringify({ kind: 'human-text-review-aggregation', planned: reviews.length,
    reviewed: judged.length, contentAndEvidencePassed: judged.filter(r => r.content && r.evidence).length,
    unknown: reviews.filter(r => !judged.includes(r)).map(r => r.id), observations: reviews }, null, 2));
} else {
  if (process.argv.length > 2) throw new Error('UNKNOWN_ARGUMENT');

// Synthetic review records. This script aggregates judgments, not model runs.
// evidence: written claims are supported by their cited material.
// content: the report fully and accurately answers the task.
const samples = [
  { id: 'normal', ran: true, execution: true, evidence: true, content: true, delivery: true },
  { id: 'wrong-content', ran: true, execution: true, evidence: false, content: false, delivery: true },
  { id: 'missing-delivery', ran: true, execution: true, evidence: true, content: true, delivery: false },
  { id: 'not-run', ran: false, execution: null, evidence: null, content: null, delivery: null },
];
const axes = ['execution', 'evidence', 'content', 'delivery'];
const executed = samples.filter(sample => sample.ran);
const completed = executed.filter(sample => axes.every(axis => sample[axis] === true));
const notRun = samples.filter(sample => !sample.ran);
assert.equal(samples.length, 4);
assert.equal(executed.length, 3);
assert.equal(completed.length, 1);
assert.equal(notRun.length, 1);
assert.ok(notRun.every(sample => axes.every(axis => sample[axis] === null)));
console.log(JSON.stringify({
  kind: 'synthetic-review-records',
  planned: samples.length,
  executed: executed.length,
  completedAmongExecuted: `${completed.length}/${executed.length}`,
  executionCoverage: `${executed.length}/${samples.length}`,
  unknown: notRun.map(sample => sample.id),
  observations: samples,
}, null, 2));

}
