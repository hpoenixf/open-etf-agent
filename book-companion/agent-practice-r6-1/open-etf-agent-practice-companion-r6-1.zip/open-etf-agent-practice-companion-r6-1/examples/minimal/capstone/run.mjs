import * as fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeReplay, run } from '../ch05/model-loop.mjs';
const here = path.dirname(fileURLToPath(import.meta.url));
const scenario = process.argv[2] ?? 'normal';
if (!['normal', 'missing-answer', 'injection'].includes(scenario) || process.argv.length > 3) throw new Error('UNKNOWN_SCENARIO');
const fixture = JSON.parse(fs.readFileSync(path.join(here, `${scenario}.json`), 'utf8'));
const result = await run({ adapter: makeReplay(fixture), sourceDir: path.join(here, 'sources'),
  task: fs.readFileSync(path.join(here, 'task-card.md'), 'utf8'), capstone: true,
  injection: scenario === 'injection', accountAnswer: scenario === 'missing-answer' ? null : '只比较免费账户' });
console.log(JSON.stringify({ scenario, directory: result.out, outcome: result.summary.outcome, externalModelCalls: result.summary.externalModelCalls }, null, 2));
const expected = { normal: 'COMPLETED', 'missing-answer': 'WAITING_FOR_ANSWER', injection: 'REFUSED' };
if (result.summary.outcome !== expected[scenario]) process.exitCode = 1;
