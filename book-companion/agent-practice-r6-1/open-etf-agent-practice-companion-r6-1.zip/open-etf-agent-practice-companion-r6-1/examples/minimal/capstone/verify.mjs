// 重新生成并验收：新建独立目录，重跑三个场景，再检查本次产物。不会验收先前 run.mjs 的目录。
import * as fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { strict as assert } from 'node:assert';
import { createHash } from 'node:crypto';
const here = path.dirname(fileURLToPath(import.meta.url));
const root = fs.mkdtempSync(path.join(process.cwd(), 'atlas-acceptance-'));
const receipts = [];
for (const scenario of ['normal', 'missing-answer', 'injection']) {
  const processResult = spawnSync(process.execPath, [path.join(here, 'run.mjs'), scenario], { cwd: root, encoding: 'utf8', timeout: 10000 });
  assert.equal(processResult.status, 0, processResult.stderr);
  const result = JSON.parse(processResult.stdout);
  const observation = JSON.parse(fs.readFileSync(path.join(result.directory, 'observation.json'), 'utf8'));
  assert.equal(observation.mode, 'synthetic-replay');
  assert.equal(observation.externalModelCalls, 0);
  const reportPath = path.join(result.directory, 'report.md');
  if (scenario === 'normal') {
    const report = fs.readFileSync(reportPath, 'utf8');
    const reference = fs.readFileSync(path.join(here, 'reference-report.md'), 'utf8');
    assert.equal(report, reference, 'REPORT_CONTENT_MISMATCH: 本次报告与固定参考正文不一致');
    assert.match(report, /120 行.*180 行.*60 行/);
    assert.match(report, /300 行.*付费上限/);
    assert.match(report, /CSV 和 Markdown/);
    assert.match(report, /两版导出均需要联网/);
    assert.match(report, /没有说明离线查看/);
    assert.deepEqual(observation.saved.sourceIds, ['A', 'B', 'B-appendix']);
    for (const receipt of observation.acquired) {
      const bytes = fs.readFileSync(path.join(here, 'sources', receipt.file));
      assert.equal(createHash('sha256').update(bytes).digest('hex'), receipt.sha256);
    }
    const reread = spawnSync(process.execPath, [path.join(here, '../ch05/model-loop.mjs'), 'readback', result.directory], { encoding: 'utf8', timeout: 10000 });
    assert.equal(reread.status, 0, reread.stderr);
    assert.equal(JSON.parse(reread.stdout).report, reference);
  } else {
    assert.equal(fs.existsSync(reportPath), false);
    assert.equal(observation.saved, null);
  }
  if (scenario === 'missing-answer') {
    assert.equal(observation.outcome, 'WAITING_FOR_ANSWER');
    assert.equal(observation.events.at(-1).result.code, 'WAITING_FOR_ANSWER');
  }
  if (scenario === 'injection') {
    assert.equal(observation.outcome, 'REFUSED');
    const attempted = observation.events.find(e => e.proposal?.name === 'send_report');
    assert(attempted, '必须真的形成外发提议，不能用“没有提议”冒充入口拦截。');
    assert.equal(attempted.result.code, 'TOOL_NOT_ALLOWED');
    assert.equal(attempted.result.dispatched, false);
  }
  receipts.push({ scenario, outcome: observation.outcome, requests: observation.requests, reportReadBack: scenario === 'normal', externalModelCalls: 0 });
}
console.log(JSON.stringify({ node: process.version, mode: 'regenerate-and-verify-new-results', reusesPreviousOutputs: false, accepted: receipts, directory: root,
  scope: 'Synthetic protocol replay and actual local file effects; not a live model or semantic grader benchmark.' }, null, 2));
