import assert from 'node:assert/strict';
// 合成的 Atlas 套餐行。付费数值只用于本章配对实验，不扩充 A/B 指南事实。
const rows = [
  { id: 'free-A', plan: 'free', version: 'A', value: 120, unit: 'rows', metric: 'per-export' },
  { id: 'free-B', plan: 'free', version: 'B', value: 300, unit: 'rows', metric: 'per-export' },
  { id: 'paid-A', plan: 'paid', version: 'A', value: 600, unit: 'rows', metric: 'per-export' },
  { id: 'paid-B', plan: 'paid', version: 'B', value: 1000, unit: 'rows', metric: 'per-export' },
];
export function difference(baseline, target) {
  if (![baseline.value, target.value].every(Number.isFinite)) throw new Error('NUMBER_REQUIRED');
  if (baseline.unit !== target.unit || baseline.metric !== target.metric) throw new Error('BASIS_MISMATCH');
  return { difference: target.value - baseline.value, rowIds: [baseline.id, target.id], unit: baseline.unit };
}
export function samePlanChange(baseline, target) {
  if (baseline.plan !== target.plan || baseline.version !== 'A' || target.version !== 'B') throw new Error('PAIR_MISMATCH');
  return difference(baseline, target);
}
const right = samePlanChange(rows[0], rows[1]);
const wrongQuestion = difference(rows[0], rows[3]);
assert.equal(right.difference, 180);
assert.equal(wrongQuestion.difference, 880);
assert.throws(() => samePlanChange(rows[0], rows[3]), /PAIR_MISMATCH/);
assert.throws(() => difference(rows[0], { ...rows[1], unit: 'MB' }), /BASIS_MISMATCH/);
console.log(JSON.stringify({ right, wrongQuestion, guardedWrongPair: 'PAIR_MISMATCH', mixedUnits: 'BASIS_MISMATCH' }, null, 2));
