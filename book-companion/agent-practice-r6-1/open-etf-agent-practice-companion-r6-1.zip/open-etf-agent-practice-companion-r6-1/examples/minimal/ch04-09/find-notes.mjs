import assert from 'node:assert/strict';
const documents = [
  { id: 'B-guide', version: 'B-2026-02', text: 'Atlas 免费账户每次最多导出300行，支持CSV和Markdown。限制见B附录。' },
  { id: 'B-appendix', version: 'B-2026-02-appendix', text: 'Atlas 的CSV和Markdown导出均需要联网。离线查看能力未说明。' },
  { id: 'old-draft', version: 'draft', text: '导出 导出 导出。旧草稿写每次500行，不属于本次范围。' },
];
const allowed = new Set(['B-guide', 'B-appendix']);
function search(query) {
  if (typeof query !== 'string' || !query.trim()) throw new Error('QUERY_REQUIRED');
  return documents.filter(d => allowed.has(d.id) && d.text.includes(query))
    .map(d => ({ id: d.id, version: d.version, acquired: false }));
}
function read(id) {
  if (!allowed.has(id)) throw new Error('SOURCE_NOT_ALLOWED');
  const document = documents.find(d => d.id === id);
  if (!document) throw new Error('SOURCE_MISSING');
  return { ...document, acquired: true };
}
const candidates = search('导出');
const acquired = candidates.map(c => read(c.id));
assert.equal(candidates.length, 2);
assert(candidates.every(c => c.acquired === false));
assert(acquired.every(c => c.acquired === true));
assert.equal(search('下载').length, 0);
assert.throws(() => read('old-draft'), /SOURCE_NOT_ALLOWED/);
console.log(JSON.stringify({ candidates, acquired, alternateQuery: search('下载'), rejected: 'old-draft' }, null, 2));
