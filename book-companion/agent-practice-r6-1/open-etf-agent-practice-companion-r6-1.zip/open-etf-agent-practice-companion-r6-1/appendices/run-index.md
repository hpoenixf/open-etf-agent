# 附录 C 运行入口与结果定位

先按书前《配套资源与复现说明》解压并校验open-etf-agent-practice-companion-r6-1.zip，再使用这份索引。公开v0.21.0不提供本书examples目录。

这份索引供读者做完一次练习后快速回查，不替代各章对输入、授权与检查标准的说明。以下工程练习使用固定公开实现与本地合成材料；环境准备已移入《准备真实项目的练习环境》，不请求真实模型，也不读取读者已有的私人记忆或数据库。

轻量路径已在Linux、Node.js 26.11.1的新空目录按正文顺序执行，包含正常结果和明确拒绝。工程路径使用固定源码与Node.js 26.11.1，详细场景见配套验证记录。一次运行成功不代表所有扩展题、模型服务或操作系统都已覆盖。

## 按章选择入口与前置结果

下表中的轻量文件位于 examples/minimal，工程入口位于 examples；完整命令在对应章与本附录后文。工程共同前置为附录D的固定源码、依赖及 BOOK_SOURCE。组合基准结果指C.2生成的 ch03-result.json。

| 章节与路线 | 入口简称 | 必要前置 | 本次期望 |
| --- | --- | --- | --- |
| 3 轻量 | first-loop | 无 | 报告或明确缺口 |
| 4 轻量 | compare-rows | 无 | 180与错配880 |
| 5 轻量 | validate-proposals；ch05/model-loop | 无 | 参数检查；读附录后保存 |
| 6 轻量 | find-notes | 无 | 两候选及实际正文 |
| 7 轻量 | 纸面方法卡 | 本章合成任务 | 可复用步骤 |
| 8 轻量 | create-table | 无 | CSV及字节回执 |
| 9 轻量 | reread-table | 先运行create-table | 同一CSV独立读回 |
| 10–11 轻量 | atlas-long-task | ask新建目录；后续用原目录 | 收到、采用、恢复分别可见 |
| 12–14、16 轻量 | atlas-boundaries | 无；选择本章模式 | 限制、记忆、许可、时间边界 |
| 15 轻量 | 纸面分工与交接 | 本章任务卡 | 说明子问题和来源 |
| 17 轻量 | reports；evaluate-samples | 先审正文，再填判断 | 3篇审阅；另练分母 |
| 结语 轻量 | capstone/run；verify | 无 | 完成、等待、拒绝三场景 |
| 3 工程 | ch03检查入口 | 组合基准结果 | 回查报告与原始结果 |
| 4、8、17 工程 | 各章检查入口 | 组合基准结果 | 来源、CSV或任务检查 |
| 5–7 工程 | 各章独立例程 | 共同前置 | 新的循环、检索或方法观察 |
| 9 工程 | book-read-http | 组合基准结果及Reader | HTTP取得同一报告 |
| 10–11 工程 | clarify-and-resume | 共同前置；例程建新任务 | 同一任务跨进程接续 |
| 12 工程 | stop-at-the-limit | 组合基准结果 | 预期停止与输入投影 |
| 13–16 工程 | 各章独立例程 | 共同前置；分别独立输出 | 本章机制的局部观察 |
| 18 工程 | guard-the-pair | 共同前置；输入自动准备 | 正常15、原错配7、前移后1次派发 |

跳读第9章时，只需先运行第8章的create-table；跳读第11章时，按该节给出的ask与answer命令建立自己的任务。工程第4、8、9、17章则统一从C.2准备基准结果，避免凭空寻找上一章目录。各章独立输出请保留实际路径。

## 轻量路径：不安装项目也能先动手

第三章使用examples/minimal/first-loop.mjs，在自己的空目录运行。正常、missing-b、early-finish和forbidden分别观察完整报告、资料缺口、过早结束与越界提议。本例只使用Node内置功能，已在26.11.1运行。

第17章的examples/minimal/ch17/evaluate-samples.mjs汇总四份合成审阅记录，也不请求模型。它不是内容裁判，不把人为给定的判断冒称为模型输出评分。

第4–9章的compare-rows、validate-proposals、find-notes、create-table与reread-table均在26.11.1分别执行。先运行create-table，再把它实际返回的目录交给reread-table，后者只读原文件。第7章的方法卡以人工练习为主，不要求安装框架。

第10–11章共用atlas-long-task.mjs，按正文先ask、提交合成回答，再在新进程中resume；保存后暂停与重读仍使用同一目录。第12、13、14、16章分别调用atlas-boundaries.mjs的limits、memory、permissions、time模式。第15章先练习纸面交接，真实子任务另有工程路径。两份新程序已在26.11.1按正常、重复和明确负例串行验证，精确范围见配套验证记录。

第三章允许只复制first-loop.mjs到空目录。第四章以后，保留配套包的examples目录树，在直接包含examples的随书目录执行命令；第十至十一章也使用examples/minimal/ch10-16/atlas-long-task.mjs这条完整相对路径。程序另外创建的输出目录存放结果，不是下一条node命令的工作目录。

公开项目练习使用另一套工作目录：在公开仓库根目录执行，并用BOOK_SOURCE指向随书目录。这样既能定位固定源码，也能调用随书程序。轻量与项目两条路径的记录分开保留。

以下保留完整工程路径的入口。它们需要固定公开项目，适合做完通用主线后深入，不是全部读者的起步条件。

## C.1 先固定两个目录

先在配套包根目录用`BOOK_SOURCE="$PWD"`并执行`export BOOK_SOURCE`记录真实位置，再进入固定公开仓库根目录工作。若另开终端，可把配套目录的真实绝对路径重新赋给BOOK_SOURCE；路径有空格时使用引号。

```bash
test -n "$BOOK_SOURCE" || { echo "请先设置配套目录"; exit 1; }
node --version
git rev-parse HEAD
```

公开提交应为b22c43633101a10a50fc5b09ecc5ecba038f873a，测试环境为Node.js 26.11.1。源码声明支持26.8.1至26.x，不把机器上另一个Node版本的存在视为当前终端已经选中它。命令输出才是这次实际使用的版本。

接收--repo参数的随书脚本通过check-base检查指定目录的Git根、提交与关键已跟踪文件变化。原ch03目录的两个文件检查入口与第9章HTTP脚本不执行这项Git检查，仍须先自行确认固定环境。它能帮助避免误用开发中的源码，不是对任意依赖、未跟踪文件或整台电脑的安全认证。若它拒绝，先确认路径和版本，不要删除检查让命令继续。

所有输出放在book-output的不同子目录。脚本的输出根与某一次真正的Run目录并不相同；实际Run路径由返回值给出。不要在示例里手抄随机生成的目录名，更不要根据文件修改时间猜哪份是目标结果。

## C.2 第一份报告是后续只读检查的共同起点

组合案例作为后续工程练习的共同起点，命令如下。运行前按项目环境附录完成固定依赖安装与构建。输出仍保留原ch03文件名，以复用已有脚本。

```bash
mkdir -p book-output
node src/cli.mjs --case portfolio-rebalance \
  --output book-output/runs \
  > book-output/ch03-result.json
node \
  "$BOOK_SOURCE/examples/ch03/inspect-first-report.mjs" \
  book-output/ch03-result.json
```

这一步留下基础简报、六份来源绑定计算CSV、一份汇总CSV和结果JSON。第4、8、9、17章会回到这份既有结果，目的分别是追数、理解附件、HTTP回读与任务关系检查。它们不是四次重新生成答案。

若想做第二次基础运行，使用新的返回值文件名，并记下它的Run目录。重新运行原命令会替换ch03-result.json这个入口文件，但不意味着旧Run自动消失。对照实验必须保留两边的身份，不能拿第二次的回执检查第一次的文件。

原ch03目录的book-check-report.mjs固定读取当前目录下的book-output/ch03-result.json；inspect-first-report.mjs则接受显式路径。二者用途相近，参数方式不同，避免把路径追加到前一个脚本后就以为它会采用。

## C.3 沿原记录观察，不修改它们

第四章检查正确配对、缺少操作数的选区，以及基础约定允许的跨类别反例。

```bash
node "$BOOK_SOURCE/examples/ch04/trace-calculation.mjs" \
  --repo . --result book-output/ch03-result.json
```

第十七章在同一批原始计算之上增加特定业务检查，既核对六类覆盖与现金关系，也确认跨类别负例能被识别。

```bash
node "$BOOK_SOURCE/examples/ch17/check-the-task.mjs" \
  --repo . --result book-output/ch03-result.json
```

两份脚本都以只读方式打开原结果，不修正报告，不更新原semanticStatus。它们生成的是新的检查观察，不能倒过来改写原运行当时知道什么或完成了什么。

第八章的CSV查看命令也只读已有文件。不要直接编辑证据CSV中的负数前导单引号；那是当前编码的公式保护行为。若另一个软件需要导入数值，先明确解析方式，不能悄悄改变文件以后仍使用旧摘要。

## C.4 为新的行为创建独立运行

第五章观察五轮循环，并创建一个没有保存报告却提前结束的负例。

```bash
node "$BOOK_SOURCE/examples/ch05/observe-the-loop.mjs" \
  --repo . --output book-output/ch05
```

第六章增加两份获准文字说明，观察候选检索、原页读取与回读。范围外草稿留在目录中，但不能进入本次来源。

```bash
node "$BOOK_SOURCE/examples/ch06/find-and-read.mjs" \
  --repo . --output book-output/ch06
```

第七章先发现并读取原创核对方法，再走原组合路径。

```bash
node "$BOOK_SOURCE/examples/ch07/reuse-the-method.mjs" \
  --repo . --output book-output/ch07
```

这些运行共享研究背景，不共享同一个Run身份。方法加载也不代表模型使用效果经过评价；当前仍是确定脚本，新增步骤只是进入了真实工具与记录路径。

第十八章再创建三个隔离场景，对照正常输入、改动前错误与提前拒绝。它使用随书业务规则和原Hook，不改动固定源码。

```bash
node "$BOOK_SOURCE/examples/ch18/guard-the-pair.mjs" \
  --repo . --output book-output/ch18
```

## C.5 通过本地HTTP重新取得文件

第九章需要一个持续运行的Reader。先从本附录C.2的组合结果取得实际Run目录，再执行官方入口。Reader返回本次origin，不使用示例端口代替它。

```bash
RUN_DIR=$(node --input-type=module -e '
  import fs from "node:fs";
  const result = JSON.parse(fs.readFileSync(
    "book-output/ch03-result.json", "utf8"
  ));
  console.log(result.directory);
')
node src/reader-cli.mjs --run "$RUN_DIR" --port 0
```

在另一个终端中，进入同一公开项目目录，设置并导出ORIGIN，再执行随书回读文件。

```bash
test -n "$BOOK_SOURCE" || { echo "请先设置配套目录"; exit 1; }
read -r -p 'Reader origin: ' ORIGIN
export ORIGIN
node "$BOOK_SOURCE/examples/ch09/book-read-http.mjs"
```

这份文件检查报告字节与修订关系。正文另给来源续接；完整验证记录还区分七份附件是否逐一下载。不能因为报告下载成功，就自动填上所有附件已核验。

结束后在Reader所在终端按Ctrl+C。关闭服务不删除报告。127.0.0.1只能表示启动服务的那台机器，将其发送给别人不会形成公共分享地址。不要为完成本地练习擅自开放所有网卡。

## C.6 提问与恢复使用同一次新补充任务

第10—11章的完整复现入口如下：

```bash
node \
  "$BOOK_SOURCE/examples/ch10/clarify-and-resume.mjs" \
  --repo . --output book-output/ch10-rehearsal
```

它依次启动五个独立Node进程，并用明确的合成回答串起主要路径。输出保留接收尚未采用、保存结果提交后停止、原Run完成等中间位置。它没有真正向用户提问，不证明任意自然语言回答都能正确处理，也没有突然杀进程。

若按正文手动分步操作，先准备现金说明、问题、项目配置与文件选择清单，再使用支持的CLI做初始化、导入、提交和查看。fixture项目的实际执行需要API注入，不能调用不支持的CLI work来替代。

主要练习只转录现金口径说明，不把导入Markdown说成重新取得六项原始行绑定。原日期和金额保持，费用缺失仍然缺失。每次恢复使用原任务身份、材料摘要与截止时间，不通过编辑数据库延长练习。

## C.7 预算、记忆与资料边界各有独立输出

第十二章包含三种限制场景和一个纯输入投影实验。

```bash
node "$BOOK_SOURCE/examples/ch12/stop-at-the-limit.mjs" \
  --repo . --result book-output/ch03-result.json \
  --output book-output/ch12
```

三个Run按预期停止，才是这些负例成功的含义。不要为了得到completed而改大限制。投影实验使用真实记录内容构造测试输入，不冒充一段刚发生的模型运行日志。

第十三章直接检查新建合成记忆库的保存、修订、遗忘和未来输入投影。

```bash
node \
  "$BOOK_SOURCE/examples/ch13/remember-and-forget.mjs" \
  --repo . --output book-output/ch13
```

它不访问读者已有的偏好库，也不删除历史文件。逻辑遗忘与物理擦除不同；脚本输出对此有明确标记。若看到写锁冲突，应确认自己选择的目录，不删除其他进程持有的锁。

第十四章使用原宿主，检查范围外读取、额外批准字段与未装配记忆工具三个拒绝。

```bash
node \
  "$BOOK_SOURCE/examples/ch14/refuse-the-instruction.mjs" \
  --repo . --output book-output/ch14
```

原文中的越权文字仍然保留，拒绝的是动作，不是把原文悄悄清洗掉。这组结果不等于真实模型完全抵抗提示注入，也不包含全部PDF、插件与受保护资料组合。

## C.8 辅助研究与计划执行分别建项目

第十五章使用独立Child项目，读取同档案说明与待核草稿，保留主任务实际消费交接的检查。

```bash
node "$BOOK_SOURCE/examples/ch15/ask-an-assistant.mjs" \
  --repo . --output book-output/ch15
```

第十六章则使用独立计划项目，前台等待一个近未来时点，再显式调用执行；精确边界使用另外的模拟Session时钟。

```bash
node \
  "$BOOK_SOURCE/examples/ch16/work-at-a-fixed-time.mjs" \
  --repo . --output book-output/ch16
```

这两个入口不在响应项目上直接叠加开关，也不与彼此组合。固定版明确拒绝几种能力组合，书中的独立项目安排是遵守接口约定，不是绕过它。

计划脚本没有后台cron，不修改系统时钟，也没有获取新行情。任务日期与原始数据日期分别检查。程序结束后不会自动在第二天再次执行，不能把一次可见的前台等待描述成长期监控已经启用。

## C.9 遇到差异时保留最小复现

先记录当前公开SHA、Node版本、执行入口、实际参数与结果状态，再看错误发生在准备、模型提议、工具派发还是文件回读。只分享必要的安全摘要，不把凭据、个人资料或全部原始日志贴进公开问题。

一次只改变一个条件。不要同时升级依赖、修改输入、换模型并增加预算，再试图判断是哪一步解决问题。保留失败目录与新的独立输出，便于比较；不要覆盖原记录，把后来结果当作当时已经完成。

最后，将“没运行”“运行后拒绝”“执行失败”“结果未知”“完成但未审阅”分开写。它们需要不同下一步。读者真正要练习的不是让每条命令都输出成功，而是能够解释程序实际做了什么，并知道下一项检查应该放在哪里。
