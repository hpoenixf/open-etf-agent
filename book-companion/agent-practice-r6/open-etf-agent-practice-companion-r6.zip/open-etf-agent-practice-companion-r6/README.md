# 《从对话到工作：研究型智能体的设计与实践》配套文件 R6

这是与第六轮审读稿一起交付的独立配套包，不是公开项目源码压缩包。解压后应得到 `open-etf-agent-practice-companion-r6` 文件夹；根目录直接包含 `examples`、`appendices`、`verify-files.mjs` 与 `file-manifest.json`。

## 先核对文件，再开始

公开获取入口位于现有项目的独立目录：[随书配套R6](https://github.com/hpoenixf/open-etf-agent/tree/book-companion-r5/book-companion/agent-practice-r6)。下载其中同名ZIP与外部SHA256清单，不需要访问私有书稿仓库。目录中的README提供本批固定内容与摘要。

公开项目v0.21.0 **没有**这里的examples目录；克隆那个历史标签不能取得本包。配套文件是单独交付，运行工程案例时仍使用历史固定源码，不随仓库main的新功能改变。

在解压目录运行：

```bash
node verify-files.mjs
```

输出 `status: matched` 表示清单中的原文件字节一致。校验器只用Node内置能力，不安装包、不联网、不读取个人目录，也不跟随清单里的符号链接。清单本身不校验自己，整个ZIP的SHA256在独立交付的 `open-etf-agent-practice-companion-r6.sha256` 中；先通过可信交付渠道核对这个值。完整性不是签名或安全认证。

如果出现 `FILE_MISSING`、`SIZE_MISMATCH` 或 `SHA256_MISMATCH`，不要直接删除检查。先确认解压完整、文件未经编辑，并核对ZIP摘要。改动练习请复制到自己的实验目录，保留原包以便对照。

## 路径一：不安装项目的轻量实验

这条路径需要Node.js，本书本轮统一推荐与验证版本为26.11.1；只使用标准库，不需要密钥或npm依赖。从配套根目录运行：

```bash
node examples/minimal/first-loop.mjs
```

它会在当前目录新建 `tiny-agent-` 开头的结果目录。按终端返回路径打开 `report.md`，不照抄随机目录名。第三章也允许只复制这个文件到空目录；第四章起保留 `examples` 树并在配套根目录运行。

9个轻量入口：first-loop；ch04-09下的compare-rows、validate-proposals、find-notes、create-table、reread-table；ch10-16下的atlas-long-task、atlas-boundaries；ch17下的evaluate-samples。路径全名及参数见运行索引。create-table的真实结果目录交给reread-table，第十、十一章接续同一任务；其他入口不会自动拼成一个大程序。

新增入口：`examples/minimal/ch05/model-loop.mjs` 默认离线回放，`examples/minimal/ch05/test-protocol.mjs` 验证协议边界；`examples/minimal/capstone/run.mjs` 运行三种毕业场景，`verify.mjs` 独立读回验收。第17章的 reports 目录提供可实际审阅的报告文本。新增真实 API 模式只在明确指定 live、模型标识及 --accept-api-cost 后启用，默认不联网。

纸书入口：输入 github.com/hpoenixf/open-etf-agent，切换到 book-companion-r5 分支查看随书资源。R5旧包保留，本包为R6；R5包内旧main资源链接已经失效，请使用独立分支入口。

## 路径二：固定公开项目的工程练习

先读 `appendices/project-setup.md`，在另一个空目录克隆公开v0.21.0并确认完整提交。该项目要求Node.js>=26.8.1且<27，书中工程环境是26.11.1。依赖安装可能联网；默认脚本仍不请求模型。

在配套根目录中先记录位置：

```bash
BOOK_SOURCE="$PWD"
export BOOK_SOURCE
```

再进入固定项目目录运行相应工程命令，保持 `BOOK_SOURCE` 指向本包。不要把它设成 `examples` 子目录，也不要把 `src` 和 `examples` 混成一个目录。

15个工程入口中，12个调用固定Git根检查，需要保留克隆的 `.git`；ch03两个入口只检查已有结果，第9章入口检查本机HTTP结果，三者不替你校准项目版本。部分练习需要先运行组合案例；第9章还需要本机Reader及ORIGIN。完整顺序见 `appendices/run-index.md`，不要一次启动全部入口。

## 包含什么

- `examples/`：原有24个章节入口及共享材料，新增模型协议循环、毕业参考成品和三篇报告审阅练习。
- `appendices/`：运行索引与项目准备说明。
- `VALIDATION.md`：真实执行范围、历史失败与尚未覆盖的部分。
- `THIRD_PARTY_NOTICES.md`：公开项目原许可与来源边界。
- `verify-files.mjs`、`file-manifest.json`、`SHA256SUMS`：原始字节清单与校验入口。

本包不包含书稿全文、图稿、私有仓库、运行数据库、凭据或依赖实体。引用、改写自Open ETF Agent v0.21.0的适用部分仍遵循原MIT许可；本书原创新增配套代码、校验器及说明未在本次发布中另授MIT或其他开源许可。公开可访问不表示仓库根目录MIT声明自动覆盖这些新增内容。读取材料、运行程序、真实模型调用分别遵守其实际范围。
